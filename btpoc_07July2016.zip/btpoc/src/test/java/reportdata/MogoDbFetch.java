package reportdata;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class MogoDbFetch {
	
	public static void main(String args[] ){
		
		MongoClient mongoClient = new MongoClient( "10.52.8.101" , 27017 );		
	    // Now connect to databases
	    DB db = mongoClient.getDB( "test" );
	    System.out.println("Connect to database successfully");
	    DBCollection coll = db.getCollection("testing2");
	    System.out.println("Collection myFirstCollection selected successfully");	   				     
	    //Retrieve Document.
	    DBCursor cursor =coll.find(new BasicDBObject(),new BasicDBObject("_id","Name")).limit(100000);
	    
	    Long starttime=System.currentTimeMillis();
	    int count=0;
    while (cursor.hasNext()) { 
	        DBObject row = cursor.next();
	      row.get("_id"); 
	       row.get("Name");
//	       System.out.println(++count);
//	       System.out.println( row.get("_id"));
	        
    }
    System.out.println(System.currentTimeMillis()- starttime+" End time :");
		
	}

}
