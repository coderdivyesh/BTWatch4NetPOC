package reportdata;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.bt.entity.template.Node;

@Document(collection = "commontemplate")
public class DemoEntity {

	private List<Node> nodes;

	public List<Node> getNodes() {
		return nodes;
	}

	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}

}
