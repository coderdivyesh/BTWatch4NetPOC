package com.bt.service.metadata.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bt.dao.metadata.MetaDataDAO;
import com.bt.entity.template.CollectionMetaData;
import com.bt.service.metadata.MetaDataService;

@Service
@Transactional 
public class MetaDataServiceImpl implements MetaDataService {

	@Autowired
	MetaDataDAO  metadatdao;
	
	@Override
	public CollectionMetaData loadMetaData(String collectionName) throws Exception {
		
		return metadatdao.loadMetaData(collectionName);
	}

}
