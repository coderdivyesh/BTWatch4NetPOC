package com.bt.service.report.template;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.bt.common.CRUDOperation;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.GlobalReportTemplate;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.Node;

public interface ReportTemplateService {
	
	public List<GlobalReportTemplate> fetchAllGlobalTemplate()  throws Exception ;
	
	public UserReportTemplate fetchUserTemplate(String username)  throws Exception ;
	
	public void insertUserTemplate(UserReportTemplate userReportTemplate, CRUDOperation operation)  throws Exception ;
	
	public void insertUserDefaultTemplate(DefaultReport defaultreport)  throws Exception ;
	
	public DefaultReport fetchUserDefaultTemplate(String userid)  throws Exception ;

	public void insertGlobalTemplate(GlobalReportTemplate globalreporttemplate,List<GlobalReportTemplate> globaltemplates,CRUDOperation operation) throws Exception;
	
	public List<GlobalReportTemplate> deleteGlobalTemplate(GlobalReportTemplate globalreporttemplate,CRUDOperation operation) throws Exception;
	
	public UserReportTemplate deleteUserNode(UserReportTemplate userreporttemplate,CRUDOperation operation)throws Exception;
	
	public void updateUserTemplate(UserReportTemplate userreporttemplate,TemplateConfiguration templateconfig) throws Exception;

}
