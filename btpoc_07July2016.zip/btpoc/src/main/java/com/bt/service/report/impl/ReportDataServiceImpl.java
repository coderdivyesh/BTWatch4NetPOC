package com.bt.service.report.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;

import com.bt.dao.report.ReportDataDAO;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.Node;
import com.bt.service.report.ReportDataService;
import com.mongodb.BasicDBObject;

/**
 * 
 * @author 611022163
 *
 */
@Service
@Transactional
public class ReportDataServiceImpl implements ReportDataService {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataServiceImpl.class);

	@Autowired
	private ReportDataDAO reportDataDAO;

	/**
	 * 
	 */
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<ReportData> getAllReports() {
		return reportDataDAO.getAllReports();
	}

	/**
	 * 
	 */
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<ReportData> getAllReports(int pagenumber, int pagesize) {
		return reportDataDAO.getAllReports(pagenumber, pagesize);
	}


  

	
	
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void insertNode(Node node) throws Exception {
		Node existnode = reportDataDAO.fetchParentNode(node);
		
		BasicDBObject whereQuery = reportDataDAO.removeNodesQuery(node);
		reportDataDAO.removeNodes(whereQuery);
		reportDataDAO.insertNodes(existnode);
	}

	@Override
	public List<ReportData> getAllReportsAccoringtoTemplate(TemplateConfiguration tempconfig) throws Exception {
		
		
		return reportDataDAO.getAllReportsAccoringtoTemplate(tempconfig,ReportData.class);
	}

	@Override
	public List<ReportData> fetchReportDataForFile(TemplateConfiguration templateconfig) throws Exception {
		
		return reportDataDAO.fetchReportDataForFile(templateconfig, ReportData.class);
	}
	
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<ReportData> getsortReport(String columnName, int flag) throws Exception {
		return reportDataDAO.getsortData(columnName,flag);
	}

	
}
