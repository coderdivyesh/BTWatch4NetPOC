package com.bt.service.email;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bt.entity.report.ReportDataList;
import com.bt.entity.report.UserReportTemplate;

public interface EmailService {

	public void sendEmail(UserReportTemplate userreporttemplate,String to, String fileFormat, HttpServletResponse response, HttpServletRequest request) throws Exception;

}
