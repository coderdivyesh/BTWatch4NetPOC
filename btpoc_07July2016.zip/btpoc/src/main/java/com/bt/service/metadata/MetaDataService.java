package com.bt.service.metadata;

import com.bt.entity.template.CollectionMetaData;

public interface MetaDataService {
	
	public CollectionMetaData loadMetaData(String collectionName) throws Exception;

}
