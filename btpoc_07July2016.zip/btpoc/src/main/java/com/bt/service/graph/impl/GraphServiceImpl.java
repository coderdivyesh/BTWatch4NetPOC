package com.bt.service.graph.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bt.dao.graph.GraphDAO;
import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;
import com.bt.service.graph.GraphService;

/**
 * 
 * @author 611022163ReportDataDAO.java
 *
 */
@Service
@Transactional
public class GraphServiceImpl implements GraphService {

	@Autowired
	GraphDAO graphDAO;
	
	@Override
	public GraphDetails fetchGraphdata(CommonData commondata) throws Exception {
		 return graphDAO.fetchGraphdata(commondata);
	}



	
}
