package com.bt.service.email.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.common.AbstractEmailDAO;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.report.UserReportTemplate;
import com.bt.service.email.EmailService;

@Service
public class EmailServiceImpl implements EmailService {

	private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	AbstractEmailDAO abstractEmailDAO;

	@Override
	public void sendEmail(UserReportTemplate userreporttemplate,String to, String fileFormat, HttpServletResponse response, HttpServletRequest request) {

		try {
			abstractEmailDAO.sendingEmail(userreporttemplate,to, fileFormat, response, request);
		} catch (Exception e) {
			System.out.println("Exception while sending email" + e.getMessage());
		}
	}

}
