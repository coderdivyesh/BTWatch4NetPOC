package com.bt.dao.graph.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.common.AbstractDAO;
import com.bt.dao.graph.GraphDAO;
import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;

/**
 * 
 * @author 611022088
 *
 */
@Repository
public  class GraphDAOImpl implements GraphDAO {

	private static final Logger logger = LoggerFactory.getLogger(GraphDAOImpl.class);
	
	@Autowired
	 AbstractDAO abstractDAO;

	public GraphDetails fetchGraphdata(CommonData commondata) throws Exception {
		return abstractDAO.fetchGraphdata(commondata);
	}
}
