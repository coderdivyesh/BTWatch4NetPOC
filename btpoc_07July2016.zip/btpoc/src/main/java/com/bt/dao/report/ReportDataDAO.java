package com.bt.dao.report;

import java.util.List;

import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.Node;
import com.mongodb.BasicDBObject;

public interface ReportDataDAO {
	
	public List<ReportData> getAllReports();
	
	public List<ReportData> getAllReports(int pagenumber,int pagesize);
	public void insertNodes(Node node) throws Exception;
	public Node fetchParentNode(Node node)throws Exception ;
	public void removeNodes(BasicDBObject query)throws Exception ;
	public BasicDBObject removeNodesQuery(Node node)throws Exception;
	
	public List<ReportData> getAllReportsAccoringtoTemplate(TemplateConfiguration templconfig,Class claz)throws Exception;
	public List<ReportData> fetchReportDataForFile(TemplateConfiguration templateconfig, Class claz) throws Exception ;

	public List<ReportData> getsortData(String columnName, int flag) throws Exception;
	

}
