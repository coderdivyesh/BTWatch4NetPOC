package com.bt.dao.report.template.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bt.common.AbstractDAO;
import com.bt.common.CRUDOperation;
import com.bt.common.Condition;
import com.bt.common.ConstantExpression;
import com.bt.common.QueryConstant;
import com.bt.common.QueryForm;
import com.bt.common.QueryFormParameter;
import com.bt.common.QueryHelper;
import com.bt.constant.OperationType;
import com.bt.dao.report.template.ReportTemplateDAO;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.GlobalReportTemplate;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.Node;
import com.bt.util.ReportHelper;
import com.mongodb.BasicDBObject;

@Repository
public class ReportTemplateDAOImpl implements ReportTemplateDAO {

	@Autowired
	AbstractDAO abstractDAO;

	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalReportTemplate> fetchAllGlobalTemplate() throws Exception {
		return (List<GlobalReportTemplate>) abstractDAO.findForCollection(GlobalReportTemplate.class);

	}

	@Override
	public List<UserReportTemplate> fetchAllUserTemplate() throws Exception {
		return (List<UserReportTemplate>) abstractDAO.findForCollection(UserReportTemplate.class);

	}
	

	public UserReportTemplate fetchUserReportTemplate(UserReportTemplate userReportTemplate,BasicDBObject basicdataobject) throws Exception {
		if (!StringUtils.isEmpty(userReportTemplate.getUsername()) && null != userReportTemplate.getNode()) {
			if (!StringUtils.isEmpty(userReportTemplate.getNode().getParentid())) {
				return (UserReportTemplate) abstractDAO.fetchSingleElement(basicdataobject,
						UserReportTemplate.class);
			}
		}
		return null;
	}
	


	private BasicDBObject removeNodesQuery(UserReportTemplate userReportTemplate) throws Exception {
		 return abstractDAO.deleteQuery( formFilterParamterforNodeDeletion(userReportTemplate),UserReportTemplate.class);
	}

	public void removeUserReportTemplateNodes(UserReportTemplate userReportTemplate) throws Exception {
		abstractDAO.delete(removeNodesQuery(userReportTemplate), UserReportTemplate.class);
		
	}

	public void insertNodes(UserReportTemplate usertemplate) throws Exception {
		abstractDAO.insert(usertemplate, UserReportTemplate.class);
	}
	
	public void insertNodes(GlobalReportTemplate globalreporttemplate) throws Exception {
		abstractDAO.insert(globalreporttemplate, GlobalReportTemplate.class);
	}
	
	public void updateNodes(UserReportTemplate usertemplate,BasicDBObject basicdataobject) throws Exception{
		abstractDAO.update(usertemplate, basicdataobject, UserReportTemplate.class);
	}
	
	public void updateNodes(GlobalReportTemplate globalreporttemplate,BasicDBObject basicdataobject) throws Exception{
		abstractDAO.update(globalreporttemplate, basicdataobject, UserReportTemplate.class);
	}
	
	public static List<QueryFormParameter> formFilterParamter(UserReportTemplate userReportTemplate) {
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter nodeid = new QueryFormParameter();
		if (null != userReportTemplate.getNode()) {
			Node inputNode=userReportTemplate.getNode();
			int nodelevel= QueryHelper.nodeLevelCounts(inputNode.getNodelevel());
			if (userReportTemplate.getId().equals(inputNode.getParentid()) && nodelevel==QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION) {
				nodeid.setColumname("id");
			} else {
				String sb="";
				for(int i=1;i<=ConstantExpression.limitCalculationForInsert(nodelevel)-1;i++)
				{
					sb=sb.concat("nodes.");
				}
				nodeid.setColumname(sb.concat("id"));
			}
			nodeid.setCondition(Condition.EQUALS);
			nodeid.setColumvalue(inputNode.getParentid());
			filterparams.add(nodeid);
		}
		if (null != userReportTemplate.getUsername()) {
			QueryFormParameter username = new QueryFormParameter();
			username.setColumname("username");
			username.setColumvalue(userReportTemplate.getUsername());
			username.setCondition(Condition.EQUALS);
			filterparams.add(username);
		}

		return filterparams;
	}
	
/**
 * 
 * @param userReportTemplate
 * @return
 */
	public static List<QueryFormParameter> formFilterParamterForSelect(UserReportTemplate userReportTemplate) {
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter nodeid = new QueryFormParameter();
		if (null != userReportTemplate.getNode()) {
			Node inputNode = userReportTemplate.getNode();
			if (!StringUtils.isEmpty(inputNode.getNodelevel())) {
				int nodecount = QueryHelper.nodeLevelCounts(inputNode.getNodelevel());
				String columname = QueryHelper.formNodeIdentifierAccordingToNodeLeveCount(nodecount,
						OperationType.SEARCH);
				nodeid.setColumname(columname);
			}
			nodeid.setCondition(Condition.EQUALS);
			nodeid.setColumvalue(inputNode.getParentid());
			filterparams.add(nodeid);
		}
		if (null != userReportTemplate.getUsername()) {
			QueryFormParameter username = new QueryFormParameter();
			username.setColumname("username");
			username.setColumvalue(userReportTemplate.getUsername());
			username.setCondition(Condition.EQUALS);
			filterparams.add(username);
		}

		return filterparams;
	}
		
	
	public static List<QueryFormParameter> formFilterParamterforNodeDeletion(UserReportTemplate userReportTemplate) {
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter nodeid = new QueryFormParameter();
		if (null != userReportTemplate.getNode()) {
			Node inputNode=userReportTemplate.getNode();
			int nodelevel= QueryHelper.nodeLevelCounts(inputNode.getNodelevel());
			if (userReportTemplate.getId().equals(inputNode.getParentid()) && nodelevel==QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION) {
				nodeid.setColumname("id");
			} else {
				
				String sb="";
				for(int i=1;i<=ConstantExpression.limitCalculationForDelete(nodelevel);i++)
				{
					sb=sb.concat("nodes.");
				}
				nodeid.setColumname(sb.concat("id"));
			}
			nodeid.setCondition(Condition.EQUALS);
			nodeid.setColumvalue(inputNode.getParentid());
			filterparams.add(nodeid);
		}
		if (null != userReportTemplate.getUsername()) {
			QueryFormParameter username = new QueryFormParameter();
			username.setColumname("username");
			username.setColumvalue(userReportTemplate.getUsername());
			username.setCondition(Condition.EQUALS);
			filterparams.add(username);
		}

		return filterparams;
	}
	
	public static List<QueryFormParameter> formFilterParamterforNodeDeletion(GlobalReportTemplate globalreporttemplate) {
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter nodeid = new QueryFormParameter();
		if (null != globalreporttemplate.getNode()) {
			Node inputNode=globalreporttemplate.getNode();
			int nodelevel= QueryHelper.nodeLevelCounts(inputNode.getNodelevel());
			if (globalreporttemplate.getId().equals(inputNode.getParentid()) && nodelevel==QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION) {
				nodeid.setColumname("id");
			} else {
				
				String sb="";
				for(int i=1;i<=ConstantExpression.limitCalculationForDelete(nodelevel);i++)
				{
					sb=sb.concat("nodes.");
				}
				nodeid.setColumname(sb.concat("id"));
			}
			nodeid.setCondition(Condition.EQUALS);
			nodeid.setColumvalue(inputNode.getParentid());
			filterparams.add(nodeid);
		}
		if (null != globalreporttemplate.getLabel()) {
			QueryFormParameter id = new QueryFormParameter();
			id.setColumname("id");
			id.setColumvalue(globalreporttemplate.getId());
			id.setCondition(Condition.EQUALS);
			filterparams.add(id);
		}

		return filterparams;
	}

	@Override
	public void insertUserDefaultTemplate(DefaultReport defaultreport) throws Exception {
		BasicDBObject wherequery = QueryForm.formQuery(formFilterParameterForDefaultReport(defaultreport));
		DefaultReport fetchdefaultreport = (DefaultReport) abstractDAO.fetchElement(wherequery, DefaultReport.class);
		if (null == fetchdefaultreport ||null==fetchdefaultreport.getCommondata()) {
			ReportHelper.pouplateDefaultReport(defaultreport);
			abstractDAO.insert(defaultreport, DefaultReport.class);
		}
	}

	
	
	private List<QueryFormParameter> formFilterParameterForDefaultReport(DefaultReport defaultreport) {
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter filterparam = new QueryFormParameter();
		filterparam.setColumname("username");
		filterparam.setColumvalue(defaultreport.getUsername());
		filterparam.setCondition(Condition.EQUALS);
		filterparams.add(filterparam);
		return filterparams;
	}

	@Override
	public DefaultReport fetchUserDefaultTemplate(String username) throws Exception {
		DefaultReport defaultreport = new DefaultReport();
		defaultreport.setUsername(username);
		BasicDBObject wherequery = QueryForm.formQuery(formFilterParameterForDefaultReport(defaultreport));
		DefaultReport fetchdefaultreport = (DefaultReport) abstractDAO.fetchElement(wherequery, DefaultReport.class);
		return fetchdefaultreport;
	}
	
	
	
	public static List<QueryFormParameter> formFilterParamter(GlobalReportTemplate globalreporttemplate) {
		

		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		QueryFormParameter nodeid = new QueryFormParameter();
		Node inputNode=globalreporttemplate.getNode();
		int nodelevel= QueryHelper.nodeLevelCounts(inputNode.getNodelevel());
		if (null != globalreporttemplate.getNode()) {
			if (globalreporttemplate.getId().equals(inputNode.getParentid()) && nodelevel==QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION) {
				nodeid.setColumname("id");
			} else {
				
				String sb="";
				for(int i=1;i<=ConstantExpression.limitCalculationForInsert(nodelevel)-1;i++)
				{
					sb=sb.concat("nodes.");
				}
				nodeid.setColumname(sb.concat("id"));
			}
			nodeid.setCondition(Condition.EQUALS);
			nodeid.setColumvalue(inputNode.getParentid());
			filterparams.add(nodeid);
		}
		if (null != globalreporttemplate.getId() && nodelevel!=QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION) {
			QueryFormParameter parentNodeId = new QueryFormParameter();
			parentNodeId.setColumname("id");
			parentNodeId.setColumvalue(globalreporttemplate.getId());
			parentNodeId.setCondition(Condition.EQUALS);
			filterparams.add(parentNodeId);
		}

		return filterparams;
	
	}
	
	

	public UserReportTemplate fetcSingleUserTemplate(String userid) throws Exception {
		UserReportTemplate usertemplate = new UserReportTemplate();
		usertemplate.setUsername(userid);
		BasicDBObject wherequery = QueryForm.formQuery(formFilterParamter(usertemplate));
		UserReportTemplate fetchusertemplate = (UserReportTemplate) abstractDAO.fetchElement(wherequery, UserReportTemplate.class);
		return fetchusertemplate;
	}

		
	public void updateDocumentArray(Node inputnode,List<QueryFormParameter> queryParam,Class claz, CRUDOperation operation) throws Exception {
		abstractDAO.updateDocumentArray(inputnode, queryParam, claz, operation);
	}
	
	
	
	@Override
	public UserReportTemplate fetchEditedUserReportTemplate(BasicDBObject basicdataobject) throws Exception {
		UserReportTemplate usertemplate = new UserReportTemplate();
		UserReportTemplate fetchusertemplate = (UserReportTemplate) abstractDAO.fetchElement(basicdataobject, UserReportTemplate.class);
		return fetchusertemplate;		
	}

	@Override
	public void deteleDocumentArray(Node inputnode, List<QueryFormParameter> queryParam, Class claz,CRUDOperation operation)throws Exception {
			abstractDAO.deleteDocumentArray(inputnode, queryParam, claz,operation);
		
	}


	
	
}
