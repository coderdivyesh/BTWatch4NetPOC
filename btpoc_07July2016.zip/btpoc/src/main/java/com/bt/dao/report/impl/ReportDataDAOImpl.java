package com.bt.dao.report.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.common.AbstractDAO;
import com.bt.common.Condition;
import com.bt.common.QueryFormParameter;
import com.bt.dao.report.ReportDataDAO;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.Node;
import com.mongodb.BasicDBObject;


/**
 * 
 * @author 611022163
 *
 */
@Repository
public  class ReportDataDAOImpl implements ReportDataDAO {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataDAOImpl.class);
	
	@Autowired
	 AbstractDAO abstractDAO;
	
/**
 * This method  will fetch record according to fetch size.
 * The mongo.fetchlimit=1000 is default . It could be change from 
 * mongo.properties file.
 * 
 */
	public List<ReportData> getAllReports(){
		return abstractDAO.selectAll();
	}

	/**
	 * This method will fetch record according to page number and page size.
	 * 
	 */
	public List<ReportData> getAllReports(int pagenumber,int pagesize){
		return abstractDAO.selectAll(pagenumber,pagesize);
	}



	public void insertNodes(Node node) throws Exception {
		abstractDAO.insert(node, Node.class);
	}
	
		@Override
	public BasicDBObject removeNodesQuery(Node node) throws Exception {
		List<QueryFormParameter> filterparams=new ArrayList<QueryFormParameter>();
		QueryFormParameter filterparam=new QueryFormParameter();
		filterparam.setColumname("id");
		filterparam.setColumvalue(node.getParentid());
		filterparam.setCondition(Condition.EQUALS);
		filterparams.add(filterparam);
		 return ( abstractDAO.deleteQuery(filterparams,Node.class) );
		
	}

	@Override
	public Node fetchParentNode(Node node) throws Exception {
		List<QueryFormParameter> filterparams=new ArrayList<QueryFormParameter>();
		QueryFormParameter filterparam=new QueryFormParameter();
		filterparam.setColumname("id");
		filterparam.setColumvalue(node.getParentid());
		filterparam.setCondition(Condition.EQUALS);
		filterparams.add(filterparam);
		List<Node> nodes= (List<Node>) abstractDAO.fetchElements(filterparams,UserReportTemplate.class);
		if(null!=nodes && !nodes.isEmpty() )
		{
			return nodes.get(0);
		}
		return null;
	}

	@Override
	public void removeNodes(BasicDBObject query) throws Exception {
		abstractDAO.delete(query, Node.class);
		
	}

	/**
	 * 
	 * @param templateconfig
	 * @param claz
	 * @return
	 * @throws Exception
	 */
	public List<ReportData> getAllReportsAccoringtoTemplate(TemplateConfiguration templateconfig,Class claz) throws Exception {
		return abstractDAO.fetchAllAccordingToTemplate(templateconfig,claz);
	}
	
	
	public List<ReportData> fetchReportDataForFile(TemplateConfiguration templateconfig, Class claz) throws Exception {
		return abstractDAO.fetchReportDataForFile(templateconfig, claz);
	}
	
	public List<ReportData> getsortData(String columnName, int flag) throws Exception {
		return abstractDAO.fetchSortData(UserReportTemplate.class, columnName,flag);
	}


}
