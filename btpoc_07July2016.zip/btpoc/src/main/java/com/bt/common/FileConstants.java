package com.bt.common;

public interface FileConstants {
	public final String CSV = "CSV";
	public final String PDF = "PDF";
	public final String TXT = "TXT";
	public final String XLS = "XLS";
}
