package com.bt.common;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.graph.GraphDetails;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.Node;
import com.bt.security.service.UserActive;
import com.bt.util.ResultSetProcessor;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
/**
 * 
 * @author 611022163
 *
 */
@Repository
public class AbstractDAO extends MongoOperationUtils implements Serializable {
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(AbstractDAO.class);
	
	private static final long serialVersionUID = 3530428536344475625L;
	


      public List<ReportData> selectAll(){
    	  return (List<ReportData>)getAllObjects(ReportData.class);
      }

      public List<ReportData> selectAll(int pagenumber, int pagesize){
      	  return (List<ReportData>)getAllObjects(ReportData.class,pagenumber,pagesize);
        }
      
   
	public GraphDetails fetchGraphdata(CommonData commondata) throws Exception {
		return (GraphDetails) fetchAllGraphData(commondata);
	}
   
	public List<?> fetchElements(List<QueryFormParameter> queryparam, Class claz) throws Exception {
		BasicDBObject basicdataobject = QueryForm.formQuery(queryparam);
		return fetchElements(basicdataobject, claz);

	}
	
	
	public Object fetchSingleElement(BasicDBObject basicdataobject, Class claz) throws Exception {
		return fetchElement(basicdataobject, claz);

	}
	
	public void insert(Object nodes,Class claz) throws Exception{
		DBObject dbobject=QueryForm.fromDBObject(nodes);
		insertDBObject(dbobject ,claz);
	}
	
	public void update(Object nodes, BasicDBObject basicdataobject, Class claz) throws Exception{
		DBObject dbobject=QueryForm.fromDBObject(nodes);
		updateDBObject(dbobject, basicdataobject,claz);
	}
	
	public void updateDocumentArray(Node inputnode,List<QueryFormParameter> queryParam, Class claz, CRUDOperation operation) throws Exception{
		BasicDBObject findQuery = QueryForm.formQuery(queryParam);
		updateObjectDocumentArray(inputnode,findQuery, claz, operation);
	}
	
	public void deleteDocumentArray(Node inputnode,List<QueryFormParameter> queryParam, Class claz, CRUDOperation operation) throws Exception{
		BasicDBObject findQuery = QueryForm.formQuery(queryParam);
		deleteObjectDocumentArray(inputnode,findQuery, claz,operation);
	}
	
	public List<?> findForCollection(Class claz) throws Exception {
		return select(claz);
	}
	
	public BasicDBObject deleteQuery(List<QueryFormParameter> queryparam, Class claz) throws Exception{		
		return QueryForm.formQueryForNodeDeletion(queryparam);
	}
	public void delete(BasicDBObject query,Class claz) throws Exception{
		deleteDBObject(query ,claz);
	}
	public List<ReportData> fetchReportDataForFile(TemplateConfiguration templateconfig, Class claz) throws Exception {
		return fetchAllAccordingToTemplateForFile(templateconfig, claz);
	}

	public List<ReportData> fetchSortData(Class claz, String columnName, int flag) {
		sortReportData(claz, columnName,flag);
		return null;
	}

  }
