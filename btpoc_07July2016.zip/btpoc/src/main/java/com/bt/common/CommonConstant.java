package com.bt.common;

public interface CommonConstant {
	public static final String DEFAULT_COLLECTION_NAME = "testing2";

	public static final String	COLLECTION_METADATA_KEY="COLLECTION_METADATA_KEY";

}
