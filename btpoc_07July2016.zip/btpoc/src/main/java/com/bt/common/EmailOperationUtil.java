package com.bt.common;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.report.UserReportTemplate;
import com.bt.service.report.ReportDataService;

public class EmailOperationUtil implements FileConstants {

	@Autowired
	ReportDataService reportDataService;

	public void sendEmail(UserReportTemplate userreporttemplate, String to, String fileFormat,
			HttpServletResponse response, HttpServletRequest request) throws Exception {

		InputStream inputStream;
		MimeBodyPart textBodyPart = null;
		ReportDataList reportdetails = new ReportDataList();
		try {
			Properties prop = new Properties();
			String propFileName = "Mail.properties";
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}

			String mailServer = prop.getProperty("mailServer");
			Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", mailServer);
			Session session = Session.getDefaultInstance(properties, null);
			textBodyPart = new MimeBodyPart();

			TemplateConfiguration templateconfig = new TemplateConfiguration();
			templateconfig.setNode(userreporttemplate.getNode());
			templateconfig.setPagenumber(1);
			List<ReportData> reportdatalist = reportDataService.fetchReportDataForFile(templateconfig);
			reportdetails.setReportdatalist(reportdatalist);
			CommonData commonfields = new CommonData();
			commonfields.setPagesize(userreporttemplate.getNode().getPagesize());
			commonfields.setDuration(userreporttemplate.getNode().getDuration());
			commonfields.setDisplayprams(userreporttemplate.getNode().getColumns());
			reportdetails.setCommondata(commonfields);

			if (!StringUtils.isEmpty(fileFormat)) {
				if (fileFormat.equals(PDF)) {
					textBodyPart.setText("PDF Text");
					MimeBodyPart pdfBodyPart = new MimeBodyPart();
					DataSource ds = EmailAttachmentHelper.createPDFMailAttachment(reportdetails, response, pdfBodyPart);
					MimeMessage mimeMessage = createMail(to, prop, session, textBodyPart, ds,pdfBodyPart);
					transportEmail(mimeMessage);

				} else if (fileFormat.equals(CSV)) {
					textBodyPart.setText("CSV Text");
					MimeBodyPart csvBodyPart = new MimeBodyPart();
					DataSource ds = EmailAttachmentHelper.createCsvMailAttachment(response, reportdetails);
					MimeMessage mimeMessage = createMail(to, prop, session, textBodyPart, ds,csvBodyPart);
					transportEmail(mimeMessage);
				} else if (fileFormat.equals(XLS)) {
					textBodyPart.setText("XLS Text");
					MimeBodyPart xlsBodyPart = new MimeBodyPart();
					DataSource ds = EmailAttachmentHelper.createXlsMailAttachment(response, reportdetails);
					MimeMessage mimeMessage = createMail(to, prop, session, textBodyPart, ds,xlsBodyPart);
					transportEmail(mimeMessage);
				}

			}
		} catch (Exception ex) {
			System.out.println("Mail not sent ..." + ex);
		}

	}

	public MimeMessage createMail(String to, Properties prop, Session session, MimeBodyPart textBodyPart,
			DataSource dataSource,MimeBodyPart pdfBodyPart) throws MessagingException, AddressException {
		pdfBodyPart.setDataHandler(new DataHandler(dataSource));
	
		MimeMultipart mimeMultipart = new MimeMultipart();
		mimeMultipart.addBodyPart(textBodyPart);
		mimeMultipart.addBodyPart(pdfBodyPart);

		InternetAddress iaSender = new InternetAddress(prop.getProperty("from"));
		InternetAddress iaRecipient = new InternetAddress(to);

		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setSender(iaSender);
		mimeMessage.setSubject("Test Mail");
		
		mimeMessage.setRecipient(Message.RecipientType.TO, iaRecipient);
		mimeMessage.setFrom(iaSender);
		mimeMessage.setContent(mimeMultipart);
		return mimeMessage;
	}

	public void transportEmail(MimeMessage mimeMessage) throws MessagingException {
		Transport.send(mimeMessage);
		System.out.println(" Mail Sent Successfully !!!! ");

	}
}
