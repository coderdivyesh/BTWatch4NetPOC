package com.bt.common;

public class ConstantExpression {

	public static int limitCalculationForInsert(int nodelevel)
	{
		return nodelevel-QueryConstant.NODE_LEVEL_INSERT_CONFIGURATION;
	}
	
	public static int limitCalculationForDelete(int nodelevel)
	{
		return nodelevel-QueryConstant.NODE_LEVEL_DELETE_CONFIGURATION;
	}
}
