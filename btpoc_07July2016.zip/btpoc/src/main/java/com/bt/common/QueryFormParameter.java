package com.bt.common;

public class QueryFormParameter {
	
	private String columname;
	private Object columvalue;
	private Condition  condition;
	
	public String getColumname() {
		return columname;
	}
	public void setColumname(String columname) {
		this.columname = columname;
	}
	public Object getColumvalue() {
		return columvalue;
	}
	public void setColumvalue(Object columvalue) {
		this.columvalue = columvalue;
	}
	public Condition getCondition() {
		return condition;
	}
	public void setCondition(Condition condition) {
		this.condition = condition;
	}
	
	

}
