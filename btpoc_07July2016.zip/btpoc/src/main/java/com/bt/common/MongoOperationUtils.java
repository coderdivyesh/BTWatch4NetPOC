package com.bt.common;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bt.config.SpringMongoConfig;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.graph.GraphDetails;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.Node;
import com.bt.entity.template.NodeColumn;
import com.bt.util.FileHelper;
import com.bt.util.ResultSetProcessor;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * This class use for crud operation
 * 
 * @author 611022163
 *
 */

public class MongoOperationUtils extends SpringMongoConfig implements QueryConstant {

	private static final Logger logger = LoggerFactory.getLogger(MongoOperationUtils.class);

	
	/**
	 * 
	 * @param claz
	 * @param pagenumber
	 * @param pagesize
	 * @return
	 * @throws Exception
	 */
	public List<ReportData> fetchAllAccordingToTemplate(TemplateConfiguration templateconfig, Class claz)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllObjectsAccordingToTemplate() : Page Number : " + templateconfig.getPagenumber());
		}
		Node node = templateconfig.getNode();
		if (null != node) {
			String collection = QueryHelper.getColletion(claz);
			BasicDBObject wherequery = QueryForm.formQueryAccordingToTemplateConfiguration(templateconfig);
			List<NodeColumn> displayparams = node.getColumns();
			BasicDBObject fields = new BasicDBObject();
			for (NodeColumn display : displayparams) {
				fields.put(display.getDbname(), 1);
			}
			DBCursor dbcourser = getCollection(collection).find(wherequery, fields)
					.skip(node.getPagesize() * (templateconfig.getPagenumber() - 1)).limit(node.getPagesize());

			//Temporary hardcode to call one time count call .as it will have seperate thread.
			if (templateconfig.getPagenumber() == 1) {
				long totalRecordCount = getCollection(collection).count();
				templateconfig.setTotalRecordCount(totalRecordCount);
			}
			return ResultSetProcessor.processResultSet(dbcourser, node.getColumns());
		}
		return null;
	}

	/**
	 * 
	 * @param templateconfig
	 * @param claz
	 * @return
	 * @throws Exception
	 */
	public List<ReportData> fetchAllAccordingToTemplateForFile(TemplateConfiguration templateconfig, Class claz)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllObjectsAccordingToTemplate() : Page Number : " + templateconfig.getPagenumber());
		}
		Node node = templateconfig.getNode();
		if (null != node) {
			String collection = QueryHelper.getColletion(claz);
			BasicDBObject wherequery = QueryForm.formQueryAccordingToTemplateConfiguration(templateconfig);
			List<NodeColumn> displayparams = node.getColumns();
			BasicDBObject fields = new BasicDBObject();
			for (NodeColumn display : displayparams) {
				fields.put(display.getDbname(), 1);
			}

			// FileHelper.fetchRecordCount() This is temporary code bcz
			// when we will consider where condition this code will need to
			// remove.

			DBCursor dbcourser = getCollection(collection).find(wherequery, fields)
					.limit(FileHelper.fetchRecordCount());
			return ResultSetProcessor.processResultSet(dbcourser, node.getColumns());
		}
		return null;
	}

	/**
	 * 
	 * @param claz
	 * @param pagenumber
	 * @param pagesize
	 * @return
	 */
	public List<ReportData> getAllObjects(Class claz, int pagenumber, int pagesize) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					" getAllObjects() : Class : " + claz + " Page Number : " + pagenumber + " Page Size : " + pagesize);
		}
		String collectionname = QueryHelper.getColletion(claz);
		DBCursor dbcourser = getCollection(collectionname).find().skip(pagesize * (pagenumber - 1)).limit(pagesize);
		return ResultSetProcessor.processResultSet(dbcourser);
	}

	/**
	 * 
	 * @param claz
	 * @return
	 */
	public List<ReportData> getAllObjects(Class claz) {
		String collectionname = QueryHelper.getColletion(claz);
		DBCursor dbcourser = getCollection(collectionname).find().limit(100);
		return ResultSetProcessor.processResultSet(dbcourser);
	}

	/**
	 * Returns aggregated data from collection for graph
	 * 
	 * @param commondata
	 * @return
	 * @throws Exception
	 */
	private AggregationOutput processQuery(CommonData commondata) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllObjectsAccordingToTemplate() : Page Number : " + commondata.getPagenumber()
					+ " Page Size : " + commondata.getPagesize() + " Template ID :" + commondata.getTemplateid()
					+ " Config ID :" + commondata.getConfigid());
		}

		String xparam = commondata.getDisplayprams().get(0).getDbname();
		String yparam = commondata.getDisplayprams().get(1).getDbname();

		DBObject match = QueryHelper.formGraphQuery(commondata, xparam, yparam);

		long samplingPerid = QueryHelper.convertToSeconds(commondata.getSamplingPeriod());

		BasicDBList divBasicList = new BasicDBList();
		divBasicList.add("$" + xparam);
		divBasicList.add(samplingPerid);
		DBObject div = new BasicDBObject($DIVIDE, divBasicList);

		BasicDBList modBasicList = new BasicDBList();
		modBasicList.add(div);
		modBasicList.add(1);
		DBObject modular = new BasicDBObject($MOD, modBasicList);

		BasicDBList subBasicList = new BasicDBList();
		subBasicList.add(div);
		subBasicList.add(modular);
		DBObject sub = new BasicDBObject($SUBTRACT, subBasicList);

		BasicDBList multiBasicList = new BasicDBList();
		multiBasicList.add(sub);
		multiBasicList.add(samplingPerid);
		DBObject multi = new BasicDBObject($MULTIPLY, multiBasicList);

		DBObject id = new BasicDBObject();
		id.put(xparam, multi);

		DBObject group = new BasicDBObject("_id", id);
		if (commondata.getAggrType().equals("count")) {
			group.put("Count", new BasicDBObject("$sum" , 1));
		} else {
			group.put(yparam, new BasicDBObject("$" + commondata.getAggrType(), "$" + yparam));
		}
			

		DBObject sort = new BasicDBObject($SORT, new BasicDBObject("_id", 1));

		@SuppressWarnings("deprecation")
		AggregationOutput dbcursor = getCollection(QueryHelper.getColletion(ReportData.class)).aggregate(new BasicDBObject($MATCH, match),
				new BasicDBObject($GROUP, group), sort);

		return dbcursor;
	}

	/**
	 * 
	 * 
	 * @param commondata
	 * @param filterParameters
	 * @return
	 * @throws Exception
	 */
	public GraphDetails fetchAllGraphData(CommonData commondata) throws Exception {
		AggregationOutput dbcourser = processQuery(commondata);
		return ResultSetProcessor.processDBCursor(dbcourser, commondata);
	}

	public List<?> fetchElements(BasicDBObject query, Class claz) throws Exception {
		String collection = QueryHelper.getColletion(claz);
		DBCursor dbcourser = getCollection(collection).find(query);
		return ResultSetProcessor.processDBCursor(dbcourser, claz);
	}

	public Object fetchElement(BasicDBObject query, Class claz) throws Exception {
		String collection = QueryHelper.getColletion(claz);
		DBCursor dbcourser = getCollection(collection).find(query);
		return ResultSetProcessor.processDBCursorForSingle(dbcourser, claz);
	}

	public List<?> findAll(Class claz) throws Exception {
		String collection = QueryHelper.getColletion(claz);
		DBCursor dbcourser = getCollection(collection).find();
		return ResultSetProcessor.processDBCursor(dbcourser, claz);
	}

	public void insertDBObject(DBObject document, Class claz) {
		String collection = QueryHelper.getColletion(claz);
		getCollection(collection).insert(document);
	}

	public void updateDBObject(DBObject dbobject, BasicDBObject basicdataobject, Class claz) {
		String collection = QueryHelper.getColletion(claz);
		getCollection(collection).update(basicdataobject, dbobject);
	}

	public void updateObjectDocumentArray(Node inputnode, BasicDBObject findQuery, Class claz, CRUDOperation operation) throws Exception {
		BasicDBObject updatequery = new BasicDBObject().append(PUSH,
				new BasicDBObject().append(
						QueryHelper.formQueryAsPerNodeLevel(QueryHelper.hierarchyIndexListForElement(inputnode.getNodelevel()), operation),
						QueryForm.fromBasicDBObject(inputnode)));
		String collection = QueryHelper.getColletion(claz);
		getCollection(collection).update(findQuery, updatequery);
	}

	public void deleteObjectDocumentArray(Node inputnode, BasicDBObject findQuery, Class claz, CRUDOperation operation) throws Exception {
		BasicDBObject updatequery = new BasicDBObject().append(PULL,
				new BasicDBObject().append(
						QueryHelper.formQueryAsPerNodeLevel(QueryHelper.hierarchyIndexListForElement(inputnode.getNodelevel()),operation),
						QueryHelper.formDeleteQueryForNode(inputnode)));
		String collection = QueryHelper.getColletion(claz);
		getCollection(collection).update(findQuery, updatequery);
	}

	public List<?> select(Class claz) throws Exception {
		String collection = QueryHelper.getColletion(claz);
		DBCursor dbcursor = getCollection(collection).find();
		return ResultSetProcessor.processDBCursor(dbcursor, claz);
	}

	public void deleteDBObject(DBObject document, Class claz) {
		String collection = QueryHelper.getColletion(claz);
		getCollection(collection).remove(document);
	}

	public void sortReportData(Class claz, String columnName, int flag)
		{
			String collection = QueryHelper.getColletion(claz);
			BasicDBObject sortQuery = new BasicDBObject().append(SORT, new BasicDBObject().append(columnName,flag));
			getCollection(collection).find(sortQuery);
	}
}
