package com.bt.common;

public enum CRUDOperation {
	INSERT,
    DELETE,
    EDIT;
}
