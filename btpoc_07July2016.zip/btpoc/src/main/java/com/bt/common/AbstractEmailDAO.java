package com.bt.common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Repository;

import com.bt.entity.report.ReportDataList;
import com.bt.entity.report.UserReportTemplate;

@Repository
public class AbstractEmailDAO extends EmailOperationUtil {

	public void sendingEmail(UserReportTemplate userreporttemplate,String to, String fileFormat, HttpServletResponse response, HttpServletRequest request) throws Exception {
		sendEmail(userreporttemplate,to, fileFormat, response, request);

	}

}
