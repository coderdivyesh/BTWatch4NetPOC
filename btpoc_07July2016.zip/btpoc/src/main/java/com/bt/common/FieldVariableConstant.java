package com.bt.common;

public interface FieldVariableConstant {
	
	public static final String EVENT_DISPLAY_NAME = "EventDisplayName";
	public static final String ELEMENT_NAME = "ElementName";
	public static final String ELEMENT_CLASS_NAME = "ElementClassName";
	public static final String DURATION = "Duration";
	public static final String CLOSED_AT = "ClosedAt";
	public static final String CLASS_NAME = "ClassName";
	public static final String CLASS_DISPLAY_NAME = "ClassDisplayName";
	public static final String CERTAINTY = "Certainty";
	public static final String CATEGORY = "Category";
	public static final String ACTIVE = "Active";
	public static final String ACKNOWLEDGED_FIRST_USER = "AcknowledgedFirstUser";
	public static final String ACKNOWLEDGED = "Acknowledged";
	public static final String OPENED_AT = "OpenedAt";
	public static final String NAME = "Name";
	public static final String ID = "_id";

}
