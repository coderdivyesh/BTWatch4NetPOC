package com.bt.common;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.StringUtils;

/**
 * 
 * @author 611022163
 *
 */
public class BTContext implements ApplicationContextAware{

	private static ApplicationContext context; 
	private static ConcurrentHashMap<String,Object> applicationmap;
	 
 	
	public static ApplicationContext getApplicationContext() { 
 		return context; 
 	} 
 

	@Override
	public void setApplicationContext(ApplicationContext basecontext) throws BeansException {
		context = basecontext;
		applicationmap = new ConcurrentHashMap<String, Object>();
	}
	
	
	
	public static Object getValueFromApplicationMap(String key) {
		if(!StringUtils.isEmpty(key) && !applicationmap.isEmpty()){
			return applicationmap.get(key);
		}
		return null;
	}
	
	
	public static void putValueToApplicationMap(String key,Object object) {
		if (!StringUtils.isEmpty(key) && null!=applicationmap) {
			applicationmap.put(key, object);
		}
		
	}
	
	
	public static void removeFromApplicationMap(String key) {
		if (!StringUtils.isEmpty(key) && !applicationmap.isEmpty()) {
			applicationmap.remove(key);
		}

	}
}
