package com.bt.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;

import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.util.ByteArrayDataSource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.bt.entity.report.ReportDataList;
import com.bt.util.ReportHelper;

public class EmailAttachmentHelper {

	public static DataSource createPDFMailAttachment(ReportDataList reportdetails, HttpServletResponse response,
			MimeBodyPart pdfBodyPart) throws MessagingException, Exception, AddressException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		createPDFFile(bos, reportdetails);
		DataSource dataSource = new ByteArrayDataSource(bos.toByteArray(), "application/pdf");
		return dataSource;
	}

	public static void createPDFFile(ByteArrayOutputStream output, ReportDataList reportdetails)
			throws IOException, Exception {
		ReportHelper.createPDF("report_details", reportdetails, output);

	}

	public static DataSource createCsvMailAttachment(HttpServletResponse response, ReportDataList reportdetails)
			throws Exception {
		StringWriter stringWriter = new StringWriter();
		createCSVFile(stringWriter, response, reportdetails);
		System.out.println(stringWriter.toString().getBytes());
		DataSource dataSource = new ByteArrayDataSource(stringWriter.toString().getBytes(), "text/csv");
		return dataSource;
	}

	public static void createCSVFile(StringWriter stringWriter, HttpServletResponse response,
			ReportDataList reportdetails) throws Exception {
		ICsvBeanWriter csvWriter = null;
		try {
			String csvFileName = "report_data.csv";
			response.setContentType("text/csv");
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
			response.setHeader(headerKey, headerValue);
			csvWriter = new CsvBeanWriter(stringWriter, CsvPreference.STANDARD_PREFERENCE);
			ReportHelper.createCSV(csvWriter, reportdetails);
		} finally {
			if (null != csvWriter) {
				csvWriter.flush();
				csvWriter.close();
			}
		}
	}

	public static DataSource createXlsMailAttachment(HttpServletResponse response, ReportDataList reportdetails)
			throws MessagingException, Exception, IOException, AddressException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		HSSFWorkbook workBook = ReportHelper.createExcel(bos, reportdetails);
		workBook.write(bos);
		DataSource dataSource = new ByteArrayDataSource(workBook.getBytes(),
				"application/vnd.ms-excel");
		return dataSource;

	}

}
