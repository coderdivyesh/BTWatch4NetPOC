package com.bt.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

public class MongoDBProperties {

	private static final String MONGO_PROPERTIES = "/mongo.properties";
   
	private static final Logger logger = LoggerFactory.getLogger(MongoDBProperties.class);
	 private static  MongoDBProperties instance=MongoDBProperties.getInstance();
	 
	@Value("mongo.dbname")
	public  String dbname;
	
	@Value("mongo.contactpoints")
	public  String contactpoints;
	
	@Value("mongo.port")
	public  Integer portnumber;
    
	@Value("mongo.fetchlimit")
	public static Integer fetchsize;

	@Value("mongo.dbCollection")
	public  String dbcollection;
	
	public  String getDbname() {
		return dbname;
	}
	public  String getContactpoints() {
		return contactpoints;
	}
	public  Integer getPortnumber() {
		return portnumber;
	}

	public  Integer getFetchsize() {
		return fetchsize;
	}


	public  String getDbcollection() {
		return dbcollection;
	}


	public static String getMongoProperties() {
		return MONGO_PROPERTIES;
	}

	
	private MongoDBProperties(){
	}
	
	public static MongoDBProperties getInstance() {
		if (null == instance) {
			instance = new MongoDBProperties();
			PropertyLoader.loadProperties(instance);
			return instance;
		}
		return instance;
	}
	
	@Override
	public String toString() {
		return "DBProperties [dbname=" + dbname + ", contactpoints=" + contactpoints + ", portnumber=" + portnumber
				+ ", fetchsize=" + fetchsize + ", dbcollection=" + dbcollection + "]";
	}
	
	

}
