package com.bt.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
/**
 * All configuration related for mongo data base . It load mongo related properties from mopngo.properties file.
 * @author 611022163
 *
 */
@Configuration
public class SpringMongoConfig{
	
	private static final Logger logger = LoggerFactory.getLogger(SpringMongoConfig.class);
	private static  MongoDBProperties mongoprop=MongoDBProperties.getInstance();
	private static  MongoClient mongoClient = new MongoClient(mongoprop.getContactpoints(),mongoprop.getPortnumber());
	
	
	
	/**
	 * 
	 * @param collectioname
	 * @return
	 */
	public DBCollection getCollection(String collectioname) {
		DBCollection collection = null;
		synchronized (SpringMongoConfig.class) {
			if (!StringUtils.isEmpty(collectioname)) {
				collection = mongoClient.getDB(mongoprop.getDbname()).getCollection(collectioname);
			} else {
				logger.error(" getCollection() : Collection name should not empty " + collectioname);
				throw new Error(" getCollection() : Collection name should not empty " + collectioname);
			}

		}
		return collection;
	}

}
