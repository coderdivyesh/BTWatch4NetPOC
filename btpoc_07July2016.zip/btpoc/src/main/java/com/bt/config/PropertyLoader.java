package com.bt.config;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Properties;

import org.apache.poi.util.SystemOutLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.util.StringUtils;

public class PropertyLoader {
	private static final String REPORT_TEMPLATE_PROPERTIES = "/reporttemplate.properties";
	private static final Logger logger = LoggerFactory.getLogger(PropertyLoader.class);

	private static Properties configProp;
	
	/**
	 * 
	 * @return
	 */
	 public static Properties loadProp() {
		 if(null==configProp){
			 loadDefaultProperties();
		 }
			return configProp;
		}
	 /**
	  * 
	  */
	private static void loadDefaultProperties() {
		if (null == configProp) {
			try {
				configProp = PropertiesLoaderUtils.loadAllProperties(REPORT_TEMPLATE_PROPERTIES);
			} catch (Exception ex) {
				logger.error("Unable to load reporttemplate.properties "+ex.getMessage(),ex);
			}
		}
	}
	
	/**
	 * 
	 * @param filepath
	 * @return
	 */
	public static Properties loadProperties(String filepath) {
			try {
				return  PropertiesLoaderUtils.loadAllProperties(filepath);
			} catch (Exception ex) {
				logger.error("Unable to load reporttemplate.properties "+ex.getMessage(),ex);
			}
			return null;
		}
	
	
	
	
	public static void loadProperties(MongoDBProperties mongo) {
		Properties loadprop = PropertyLoader.loadProperties(mongo.getMongoProperties());
		Field[] fields = MongoDBProperties.class.getDeclaredFields();
		try {
			for (Field field : fields) {
				String fieldpropname = getPoprtyName(field);
				if (!StringUtils.isEmpty(fieldpropname)) {
					if (field.getType().isAssignableFrom(Integer.class)) {
						int value = Integer.parseInt((String) loadprop.get(fieldpropname));
						field.setAccessible(Boolean.TRUE);
						field.set(mongo, value);
					}
					if (field.getType().isAssignableFrom(String.class)) {
						String value = String.valueOf(loadprop.get(fieldpropname));
						field.setAccessible(Boolean.TRUE);
						field.set(mongo, value);
					}
				}
			}
		} catch (Exception ex) {
			logger.error(" MongoDBProperties() :" + ex, ex.getMessage());
		}
	}
    
	
	private static String getPoprtyName(Field fieldz) {
		if (fieldz.isAnnotationPresent(Value.class)) {
			Annotation ety = fieldz.getDeclaredAnnotation(Value.class);
			if (ety instanceof Value) {
				Value myAnnotation = (Value) ety;
				return myAnnotation.value();
			}
		}
		return null;
	}
    	
	
}
