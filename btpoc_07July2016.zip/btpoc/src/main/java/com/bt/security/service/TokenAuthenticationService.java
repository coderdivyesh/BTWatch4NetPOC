package com.bt.security.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;

import com.bt.security.entity.UserVO;
import com.bt.security.helper.TokenHandler;


public class TokenAuthenticationService implements  TokenAuthenticationConstant {
 

    private final TokenHandler tokenHandler;

  
	public TokenAuthenticationService(String secret, UserService userService) {
        tokenHandler = new TokenHandler(secret, userService);
    }

    public String addAuthentication( HttpHeaders header, UserAuthentication authentication) {
        final UserVO user = authentication.getDetails();
        String token = tokenHandler.createTokenForUser(user);
        header.set(AUTH_HEADER_NAME, token);
        return token;
    }

    public Authentication getAuthentication(HttpServletRequest request) {
        final String token = request.getHeader(AUTH_HEADER_NAME);
       
        if (token != null) {
            final UserVO user = tokenHandler.parseUserFromToken(token);
            if (user != null) {
            	UserAuthentication useauth=new UserAuthentication(user);
            	useauth.setAuthenticated(Boolean.TRUE);
                return useauth;
            }
        }
        return null;
    }

	public TokenHandler getTokenHandler() {
		return tokenHandler;
	}
    

}
