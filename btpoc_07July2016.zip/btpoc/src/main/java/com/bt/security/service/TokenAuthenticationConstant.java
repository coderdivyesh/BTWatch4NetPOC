package com.bt.security.service;

public interface TokenAuthenticationConstant {
	
	  public static final String AUTH_HEADER_NAME = "AUTH-TOKEN";

}
