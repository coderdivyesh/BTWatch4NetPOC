package com.bt.security.service;

import java.util.Base64;
import java.util.HashMap;

import javax.security.sasl.AuthenticationException;

import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.StringUtils;

import com.bt.security.entity.UserVO;

public class UserService implements UserDetailsService {

    private  static final AccountStatusUserDetailsChecker detailsChecker = new AccountStatusUserDetailsChecker();
    private static HashMap<String, UserVO> userMap = new HashMap<String, UserVO>();

   
    public  final  UserVO loadUserByUsername(String username) throws UsernameNotFoundException {
         UserVO user = userMap.get(username);
        if (user == null) {
        		throw new UsernameNotFoundException("user not found");
        }
        detailsChecker.check(user);
        return user;
    }
    
    public  final  UserVO validateUser(String username,String password) throws UsernameNotFoundException {
        UserVO user = userMap.get(username);
        if(null==user){
        	throw new UsernameNotFoundException("user not found");
        }
		if (!StringUtils.isEmpty(user.getPassword())) {
			String encodepassword = Base64.getEncoder().encodeToString(password.getBytes());
			if (!user.getPassword().equals(encodepassword)) {
				throw new UsernameNotFoundException("user not found");
			}
		}
       detailsChecker.check(user);
       return user;
   }
    
     public static  HashMap<String, UserVO> getAllUser(){
    	 return userMap;
    	 
     }
    
    public  static void  addUser(UserVO user) {
        userMap.put(user.getUsername(), user);
    }
    
    
    
    public  static  UserVO findUserByUsername(String username) throws UsernameNotFoundException {
        UserVO user = userMap.get(username);
       if (user == null) {
       		throw new UsernameNotFoundException("user not found");
       }
       detailsChecker.check(user);
       return user;
   }
}
