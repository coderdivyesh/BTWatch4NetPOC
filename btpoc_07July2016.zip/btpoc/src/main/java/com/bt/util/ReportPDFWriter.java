package com.bt.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import com.bt.entity.report.ReportDataList;
import com.bt.entity.template.NodeColumn;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
/**
 * 
 * @author 611022163
 *
 */
public class ReportPDFWriter {

	public static final String EXTENSION = ".pdf";
	public String PRESCRIPTION_URL = "template.xsl";

	private static ReportPDFWriter instance;

	private ReportPDFWriter() {

	}

	public static ReportPDFWriter getInstance() {
		if (null == instance) {
			synchronized (ReportPDFWriter.class) {
				if (null == instance) {
					instance = new ReportPDFWriter();
				}
			}
		}
		return instance;
	}

	/**
	 * 
	 * @param filename
	 * @param reportlist
	 * @throws Exception
	 */
	public void  createPDFContent(String fileName,ReportDataList reportdetails,OutputStream outputstream) throws Exception {
		Document document = new Document();
		PdfWriter.getInstance(document, outputstream);
		document.open();
		Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 8, Font.BOLD, new BaseColor(0, 0, 0));
		Font bf12 = new Font(FontFamily.TIMES_ROMAN, 4);
		document.setPageSize(PageSize.A4);
		Paragraph paragraph = new Paragraph(" Details of report form mongo DB ");
		List<NodeColumn> filterparams = reportdetails.getCommondata().getDisplayprams();
		String[] header = FileHelper.getHeaderList(filterparams);
		PdfPTable table = new PdfPTable(header.length);
		PDFHelper.pdfHeaderWriter(table, header, bf12);
		PDFHelper.pdfContentWriter(table, reportdetails.getReportdatalist(), bf12, document, paragraph,filterparams);
	}

	
	/**
	 * 
	 * @param filename
	 * @param reportlist
	 * @throws Exception
	 */
	public void  createPDFContent(String fileName,ReportDataList reportdetails,ByteArrayOutputStream outputstream) throws Exception {
		Document document = new Document();
		PdfWriter.getInstance(document, outputstream);
		document.open();
		Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 8, Font.BOLD, new BaseColor(0, 0, 0));
		Font bf12 = new Font(FontFamily.TIMES_ROMAN, 4);
		document.setPageSize(PageSize.A4);
		Paragraph paragraph = new Paragraph(" Details of report form mongo DB ");
		List<NodeColumn> filterparams = reportdetails.getCommondata().getDisplayprams();
		String[] header = FileHelper.getHeaderList(filterparams);
		PdfPTable table = new PdfPTable(header.length);
		PDFHelper.pdfHeaderWriter(table, header, bf12);
		PDFHelper.pdfContentWriter(table, reportdetails.getReportdatalist(), bf12, document, paragraph,filterparams);
	}
}
