package com.bt.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Properties;

import org.springframework.util.StringUtils;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;

import com.bt.config.PropertyLoader;
import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.NodeColumn;



/**
 * 
 * @author 611022163
 *
 */
public class FileHelper {
	private static final String DEFAULT_RECORD_COUNT = "10000";

	private static final String RECORDCOUNTFORFILEDOWNLOAD = "recordcountforfiledownload";
	
	static Properties properties = PropertyLoader.loadProp();
    /**
     * 
     * @param fields
     * @return
     * @throws Exception
     */
	public static CellProcessor[] getProcessors(String[] fields) throws Exception {
		final CellProcessor[] processors = new CellProcessor[fields.length];
		for (int row = 0; row < fields.length; row++) {
			Field fetchfield = ReportData.class.getDeclaredField(fields[row]);
			if (fetchfield.getType().isAssignableFrom(String.class)) {
				processors[row] = new NotNull();
			} else {
				processors[row] = new Optional();
			}
		}
		return processors;
	}

	/**
	 * 
	 * @param filename
	 * @param reportlist
	 * @return
	 * @throws Exception
	 */
	public static InputStream createTXT(String filename, List<ReportData> reportlist) throws Exception {
		return new ByteArrayInputStream(reportlist.toString().getBytes("UTF8"));
	}

	/**
	 * 
	 * @param common
	 * @return
	 */
	public static String getPropertieskeyForTemplate(CommonData common) {
		Properties properties = PropertyLoader.loadProp();
		String key = "report.template." + common.getTemplateid() + "." + common.getConfigid();
		return properties.getProperty(key);
	}

	/**
	 * 
	 * @param filterparams
	 * @return
	 */
	public static String[] getHeaderList(List<NodeColumn> filterparams) {

		String[] header = null;
		if (null != filterparams && !filterparams.isEmpty()) {
			int arraysize = filterparams.size();
			header = new String[arraysize];
			for (int i = 0; i < arraysize; i++) {
				header[i] = filterparams.get(i).getDbname();
			}
		}
		return header;
	}
	/**
	 * 
	 * @param filterparams
	 * @return
	 */
	public static String[] getFieldList(List<NodeColumn> filterparams) {

		String[] fieldname = null;
		if (null != filterparams && !filterparams.isEmpty()) {
			int arraysize = filterparams.size();
			fieldname = new String[arraysize];
			for (int i = 0; i < arraysize; i++) {
				fieldname[i] = filterparams.get(i).getName();
			}
		}
		return fieldname;
	}
	
	
	public static int fetchRecordCount() {
		String recordcount= (String) properties.get(RECORDCOUNTFORFILEDOWNLOAD);
		if(StringUtils.isEmpty(recordcount)){
			recordcount=DEFAULT_RECORD_COUNT;
		}
		return Integer.parseInt(recordcount);
	}
}
