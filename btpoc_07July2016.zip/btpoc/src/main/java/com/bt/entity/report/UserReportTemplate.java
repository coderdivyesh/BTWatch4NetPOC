package com.bt.entity.report;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.bt.entity.template.Node;

@Document(collection="userreport")
public class UserReportTemplate {
	private String username;
	private String parentid;
	private String id;
	private String label;
	private String filterExpression;
	private Node node;

	private List<Node> nodes;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParentid() {
		return parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getFilterExpression() {
		return filterExpression;
	}

	public void setFilterExpression(String filterExpression) {
		this.filterExpression = filterExpression;
	}

	public List<Node> getNodes() {
		return nodes;
	}

	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	@Override
	public String toString() {
		return "UserReportTemplate [username=" + username + ", parentid=" + parentid + ", id=" + id + ", label=" + label
				+ ", filterExpression=" + filterExpression + ", node=" + node + ", nodes=" + nodes + "]";
	}


	
}
