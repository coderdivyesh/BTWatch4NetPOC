package com.bt.entity.report;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
/**
 * 
 * This pojo class holds all report related column available in database. 
 * @author 611022163
 *
 */
@Document(collection = "testing2")
public class ReportData  {

	@Id
	@Field("_id")
	private long id;

	@Field("Name")
	private String name;
	
	@Field("OpenedAt")
	private int openedat;

	@Field("Acknowledged")
	private byte acknowledged;

	@Field("AcknowledgedFirstUser")
	private String acknowledgedFirstUser;

	@Field("Active")
	private byte active;

	@Field("Category")
	private String category;

	@Field("Certainty")
	private float certainty;

	@Field("ClassDisplayName")
	private String classdisplayname;

	@Field("ClassName")
	private String className;

	@Field("ClosedAt")
	private int closeDat;

	@Field("Duration")
	private int duration;

	@Field("ElementClassName")
	private String elementclassname;

	@Field("ElementName")
	private String elementname;

	@Field("EventDisplayName")
	private String eventdisplayname;

	@Field("EventName")
	private String eventname;

	@Field("EventText")
	private String eventtext;

	@Field("EventType")
	private String eventtype;

	@Field("FirstNotifiedAt")
	private int firstnotifiedat;

	@Field("FirstTimeToAcknowledged")
	private int firsttimetoacknowledged;

	@Field("FirstTimeToOwner")
	private int firsttimetoowner;

	@Field("FirstTimeToTroubleTicketID")
	private int firsttimetotroubleticketid;

	@Field("Impact")
	private long impact;

	@Field("InMaintenance")
	private byte inmaintenance;

	@Field("InstanceDisplayName")
	private String instancedisplayname;

	@Field("InstanceName")
	private String instancename;

	@Field("IsProblem")
	private byte isproblem;

	@Field("IsRoot")
	private byte isroot;

	@Field("IsRootFirstvalue")
	private byte isrootfirstvalue;

	@Field("LastChangedAt")
	private int lastchangedat;

	@Field("OccurrenceCount")
	private int occurrencecount;

	@Field("Owner")
	private String owner;

	@Field("OwnerFirstUser")
	private String ownerfirstuser;

	@Field("Severity")
	private byte severity;

	@Field("Source")
	private String source;

	@Field("SourceDomainName")
	private String sourcedomainname;

	@Field("SourceEventType")
	private String sourceeventtype;

	@Field("TroubleTicketID")
	private String troubleticketid;

	@Field("TroubleTicketIDFirstValue")
	private String troubleticketidfirstvalue;
	
	@Field("TroubleTicketIDFirstUser")
	private int troubleticketidfirstuser;


	@Field("updatedat")
	private int updatedat;

	@Field("UserDefined1")
	private String userdefined1;

	@Field("UserDefined2")
	private String userdefined2;

	@Field("UserDefined3")
	private String userdefined3;

	@Field("UserDefined4")
	private String userdefined4;

	@Field("UserDefined5")
	private String userdefined5;

	@Field("UserDefined6")
	private String userdefined6;

	@Field("UserDefined7")
	private String userdefined7;

	@Field("UserDefined8")
	private String userdefined8;

	@Field("UserDefined9")
	private String userdefined9;

	@Field("UserDefined10")
	private String userdefined10;

	@Field("UserDefinedd11")
	private String userdefined11;

	@Field("UserDefined12")
	private String userdefined12;

	@Field("UserDefined13")
	private String userdefined13;

	@Field("UserDefined14")
	private String userdefined14;

	@Field("UserDefined15")
	private String userdefined15;

	@Field("UserDefined16")
	private String userdefined16;

	@Field("UserDefined17")
	private String userdefined17;

	@Field("UserDefined18")
	private String userdefined18;

	@Field("UserDefined19")
	private String userdefined19;

	@Field("UserDefined20")
	private String userdefined20;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOpenedat() {
		return openedat;
	}

	public void setOpenedat(int openedat) {
		this.openedat = openedat;
	}

	public byte getAcknowledged() {
		return acknowledged;
	}

	public void setAcknowledged(byte acknowledged) {
		this.acknowledged = acknowledged;
	}

	public String getAcknowledgedFirstUser() {
		return acknowledgedFirstUser;
	}

	public void setAcknowledgedFirstUser(String acknowledgedFirstUser) {
		this.acknowledgedFirstUser = acknowledgedFirstUser;
	}

	public byte getActive() {
		return active;
	}

	public void setActive(byte active) {
		this.active = active;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getCertainty() {
		return certainty;
	}

	public void setCertainty(float certainty) {
		this.certainty = certainty;
	}

	public String getClassdisplayname() {
		return classdisplayname;
	}

	public void setClassdisplayname(String classdisplayname) {
		this.classdisplayname = classdisplayname;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public int getCloseDat() {
		return closeDat;
	}

	public void setCloseDat(int closeDat) {
		this.closeDat = closeDat;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getElementclassname() {
		return elementclassname;
	}

	public void setElementclassname(String elementclassname) {
		this.elementclassname = elementclassname;
	}

	public String getElementname() {
		return elementname;
	}

	public void setElementname(String elementname) {
		this.elementname = elementname;
	}

	public String getEventdisplayname() {
		return eventdisplayname;
	}

	public void setEventdisplayname(String eventdisplayname) {
		this.eventdisplayname = eventdisplayname;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getEventtext() {
		return eventtext;
	}

	public void setEventtext(String eventtext) {
		this.eventtext = eventtext;
	}

	public String getEventtype() {
		return eventtype;
	}

	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}

	public int getFirstnotifiedat() {
		return firstnotifiedat;
	}

	public void setFirstnotifiedat(int firstnotifiedat) {
		this.firstnotifiedat = firstnotifiedat;
	}

	public int getFirsttimetoacknowledged() {
		return firsttimetoacknowledged;
	}

	public void setFirsttimetoacknowledged(int firsttimetoacknowledged) {
		this.firsttimetoacknowledged = firsttimetoacknowledged;
	}

	public int getFirsttimetoowner() {
		return firsttimetoowner;
	}

	public void setFirsttimetoowner(int firsttimetoowner) {
		this.firsttimetoowner = firsttimetoowner;
	}

	public int getFirsttimetotroubleticketid() {
		return firsttimetotroubleticketid;
	}

	public void setFirsttimetotroubleticketid(int firsttimetotroubleticketid) {
		this.firsttimetotroubleticketid = firsttimetotroubleticketid;
	}

	public long getImpact() {
		return impact;
	}

	public void setImpact(long impact) {
		this.impact = impact;
	}

	public byte getInmaintenance() {
		return inmaintenance;
	}

	public void setInmaintenance(byte inmaintenance) {
		this.inmaintenance = inmaintenance;
	}

	public String getInstancedisplayname() {
		return instancedisplayname;
	}

	public void setInstancedisplayname(String instancedisplayname) {
		this.instancedisplayname = instancedisplayname;
	}

	public String getInstancename() {
		return instancename;
	}

	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}

	public byte getIsproblem() {
		return isproblem;
	}

	public void setIsproblem(byte isproblem) {
		this.isproblem = isproblem;
	}

	public byte getIsroot() {
		return isroot;
	}

	public void setIsroot(byte isroot) {
		this.isroot = isroot;
	}

	public byte getIsrootfirstvalue() {
		return isrootfirstvalue;
	}

	public void setIsrootfirstvalue(byte isrootfirstvalue) {
		this.isrootfirstvalue = isrootfirstvalue;
	}

	public int getLastchangedat() {
		return lastchangedat;
	}

	public void setLastchangedat(int lastchangedat) {
		this.lastchangedat = lastchangedat;
	}

	public int getOccurrencecount() {
		return occurrencecount;
	}

	public void setOccurrencecount(int occurrencecount) {
		this.occurrencecount = occurrencecount;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerfirstuser() {
		return ownerfirstuser;
	}

	public void setOwnerfirstuser(String ownerfirstuser) {
		this.ownerfirstuser = ownerfirstuser;
	}

	public byte getSeverity() {
		return severity;
	}

	public void setSeverity(byte severity) {
		this.severity = severity;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourcedomainname() {
		return sourcedomainname;
	}

	public void setSourcedomainname(String sourcedomainname) {
		this.sourcedomainname = sourcedomainname;
	}

	public String getSourceeventtype() {
		return sourceeventtype;
	}

	public void setSourceeventtype(String sourceeventtype) {
		this.sourceeventtype = sourceeventtype;
	}

	public String getTroubleticketid() {
		return troubleticketid;
	}

	public void setTroubleticketid(String troubleticketid) {
		this.troubleticketid = troubleticketid;
	}

	public String getTroubleticketidfirstvalue() {
		return troubleticketidfirstvalue;
	}

	public void setTroubleticketidfirstvalue(String troubleticketidfirstvalue) {
		this.troubleticketidfirstvalue = troubleticketidfirstvalue;
	}

	public int getUpdatedat() {
		return updatedat;
	}

	public void setUpdatedat(int updatedat) {
		this.updatedat = updatedat;
	}

	public String getUserdefined1() {
		return userdefined1;
	}

	public void setUserdefined1(String userdefined1) {
		this.userdefined1 = userdefined1;
	}

	public String getUserdefined2() {
		return userdefined2;
	}

	public void setUserdefined2(String userdefined2) {
		this.userdefined2 = userdefined2;
	}

	public String getUserdefined3() {
		return userdefined3;
	}

	public void setUserdefined3(String userdefined3) {
		this.userdefined3 = userdefined3;
	}

	public String getUserdefined4() {
		return userdefined4;
	}

	public void setUserdefined4(String userdefined4) {
		this.userdefined4 = userdefined4;
	}

	public String getUserdefined5() {
		return userdefined5;
	}

	public void setUserdefined5(String userdefined5) {
		this.userdefined5 = userdefined5;
	}

	public String getUserdefined6() {
		return userdefined6;
	}

	public void setUserdefined6(String userdefined6) {
		this.userdefined6 = userdefined6;
	}

	public String getUserdefined7() {
		return userdefined7;
	}

	public void setUserdefined7(String userdefined7) {
		this.userdefined7 = userdefined7;
	}

	public String getUserdefined8() {
		return userdefined8;
	}

	public void setUserdefined8(String userdefined8) {
		this.userdefined8 = userdefined8;
	}

	public String getUserdefined9() {
		return userdefined9;
	}

	public void setUserdefined9(String userdefined9) {
		this.userdefined9 = userdefined9;
	}

	public String getUserdefined10() {
		return userdefined10;
	}

	public void setUserdefined10(String userdefined10) {
		this.userdefined10 = userdefined10;
	}

	public String getUserdefined11() {
		return userdefined11;
	}

	public void setUserdefined11(String userdefined11) {
		this.userdefined11 = userdefined11;
	}

	public String getUserdefined12() {
		return userdefined12;
	}

	public void setUserdefined12(String userdefined12) {
		this.userdefined12 = userdefined12;
	}

	public String getUserdefined13() {
		return userdefined13;
	}

	public void setUserdefined13(String userdefined13) {
		this.userdefined13 = userdefined13;
	}

	public String getUserdefined14() {
		return userdefined14;
	}

	public void setUserdefined14(String userdefined14) {
		this.userdefined14 = userdefined14;
	}

	public String getUserdefined15() {
		return userdefined15;
	}

	public void setUserdefined15(String userdefined15) {
		this.userdefined15 = userdefined15;
	}

	public String getUserdefined16() {
		return userdefined16;
	}

	public void setUserdefined16(String userdefined16) {
		this.userdefined16 = userdefined16;
	}

	public String getUserdefined17() {
		return userdefined17;
	}

	public void setUserdefined17(String userdefined17) {
		this.userdefined17 = userdefined17;
	}

	public String getUserdefined18() {
		return userdefined18;
	}

	public void setUserdefined18(String userdefined18) {
		this.userdefined18 = userdefined18;
	}

	public String getUserdefined19() {
		return userdefined19;
	}

	public void setUserdefined19(String userdefined19) {
		this.userdefined19 = userdefined19;
	}

	public String getUserdefined20() {
		return userdefined20;
	}

	public void setUserdefined20(String userdefined20) {
		this.userdefined20 = userdefined20;
	}

	public int getTroubleticketidfirstuser() {
		return troubleticketidfirstuser;
	}

	public void setTroubleticketidfirstuser(int troubleticketidfirstuser) {
		this.troubleticketidfirstuser = troubleticketidfirstuser;
	}

	@Override
	public String toString() {
		return "ReportData [id=" + id + ", name=" + name + ", openedat=" + openedat + ", acknowledged=" + acknowledged
				+ ", acknowledgedFirstUser=" + acknowledgedFirstUser + ", active=" + active + ", category=" + category
				+ ", certainty=" + certainty + ", classdisplayname=" + classdisplayname + ", className=" + className
				+ ", closeDat=" + closeDat + ", duration=" + duration + ", elementclassname=" + elementclassname
				+ ", elementname=" + elementname + ", eventdisplayname=" + eventdisplayname + ", eventname=" + eventname
				+ ", eventtext=" + eventtext + ", eventtype=" + eventtype + ", firstnotifiedat=" + firstnotifiedat
				+ ", firsttimetoacknowledged=" + firsttimetoacknowledged + ", firsttimetoowner=" + firsttimetoowner
				+ ", firsttimetotroubleticketid=" + firsttimetotroubleticketid + ", impact=" + impact
				+ ", inmaintenance=" + inmaintenance + ", instancedisplayname=" + instancedisplayname
				+ ", instancename=" + instancename + ", isproblem=" + isproblem + ", isroot=" + isroot
				+ ", isrootfirstvalue=" + isrootfirstvalue + ", lastchangedat=" + lastchangedat + ", occurrencecount="
				+ occurrencecount + ", owner=" + owner + ", ownerfirstuser=" + ownerfirstuser + ", severity=" + severity
				+ ", source=" + source + ", sourcedomainname=" + sourcedomainname + ", sourceeventtype="
				+ sourceeventtype + ", troubleticketid=" + troubleticketid + ", troubleticketidfirstvalue="
				+ troubleticketidfirstvalue + ", troubleticketidfirstuser=" + troubleticketidfirstuser + ", updatedat="
				+ updatedat + ", userdefined1=" + userdefined1 + ", userdefined2=" + userdefined2 + ", userdefined3="
				+ userdefined3 + ", userdefined4=" + userdefined4 + ", userdefined5=" + userdefined5 + ", userdefined6="
				+ userdefined6 + ", userdefined7=" + userdefined7 + ", userdefined8=" + userdefined8 + ", userdefined9="
				+ userdefined9 + ", userdefined10=" + userdefined10 + ", userdefined11=" + userdefined11
				+ ", userdefined12=" + userdefined12 + ", userdefined13=" + userdefined13 + ", userdefined14="
				+ userdefined14 + ", userdefined15=" + userdefined15 + ", userdefined16=" + userdefined16
				+ ", userdefined17=" + userdefined17 + ", userdefined18=" + userdefined18 + ", userdefined19="
				+ userdefined19 + ", userdefined20=" + userdefined20 + "]";
	}


}
