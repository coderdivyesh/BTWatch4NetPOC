package com.bt.entity.template;

import com.bt.constant.FilterCondition;

/**
 * 
 * @author 611022163
 *
 */
public class ExpressionDetails {
	

	private Object value;
	private String key;
	private String datatype;
	private FilterCondition innerJoinOpeartion;
	private FilterCondition outerJoinOperation;
	
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public FilterCondition getInnerJoinOpeartion() {
		return innerJoinOpeartion;
	}
	public void setInnerJoinOpeartion(FilterCondition innerJoinOpeartion) {
		this.innerJoinOpeartion = innerJoinOpeartion;
	}
	public FilterCondition getOuterJoinOperation() {
		return outerJoinOperation;
	}
	public void setOuterJoinOperation(FilterCondition outerJoinOperation) {
		this.outerJoinOperation = outerJoinOperation;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	
	@Override
	public String toString() {
		return "ExpressionDetails [value=" + value + ", key=" + key + ", datatype=" + datatype + ", innerJoinOpeartion="
				+ innerJoinOpeartion + ", outerJoinOperation=" + outerJoinOperation + "]";
	}
	
	
	
}
