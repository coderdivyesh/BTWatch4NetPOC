package com.bt.entity.report;

import java.util.List;

import com.bt.entity.common.CommonData;

public class ReportDataList {


	private List<ReportData> reportdatalist;
	
	private CommonData commondata;

	public List<ReportData> getReportdatalist() {
		return reportdatalist;
	}

	public void setReportdatalist(List<ReportData> reportdatalist) {
		this.reportdatalist = reportdatalist;
	}

	public CommonData getCommondata() {
		return commondata;
	}

	public void setCommondata(CommonData commondata) {
		this.commondata = commondata;
	}

	@Override
	public String toString() {
		return "ReportDataList [reportdatalist=" + reportdatalist + ", commondata=" + commondata + "]";
	}
	
	
}
