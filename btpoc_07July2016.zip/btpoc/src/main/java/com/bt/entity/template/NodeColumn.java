package com.bt.entity.template;

public class NodeColumn {
	private String label;
	private String name;
	private String dbname;
	private String  datatype;
	private String friendlyname;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDbname() {
		return dbname;
	}
	public void setDbname(String dbname) {
		this.dbname = dbname;
	}
	
	public String getFriendlyname() {
		return friendlyname;
	}
	public void setFriendlyname(String friendlyname) {
		this.friendlyname = friendlyname;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	
	@Override
	public String toString() {
		return "NodeColumn [label=" + label + ", name=" + name + ", dbname=" + dbname + ", datatype=" + datatype
				+ ", friendlyname=" + friendlyname + "]";
	}
	
	
}
