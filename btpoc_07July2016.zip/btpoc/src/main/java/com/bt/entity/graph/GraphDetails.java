package com.bt.entity.graph;

import java.util.Map;

public class GraphDetails {
	
	private String xfieldName;
	private String yfieldName;
	private Map<String,Object> graphvalues;
	
	public String getXfieldName() {
		return xfieldName;
	}
	public void setXfieldName(String xfieldName) {
		this.xfieldName = xfieldName;
	}
	public String getYfieldName() {
		return yfieldName;
	}
	public void setYfieldName(String yfieldName) {
		this.yfieldName = yfieldName;
	}
	public Map<String, Object> getGraphvalues() {
		return graphvalues;
	}
	public void setGraphvalues(Map<String, Object> graphvalues) {
		this.graphvalues = graphvalues;
	}
	
	@Override
	public String toString() {
		return "GraphDetails [xfieldName=" + xfieldName + ", yfieldName=" + yfieldName + ", graphvalues=" + graphvalues
				+ "]";
	}
}
