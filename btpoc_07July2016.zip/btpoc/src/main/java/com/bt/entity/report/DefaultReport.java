package com.bt.entity.report;

import org.springframework.data.mongodb.core.mapping.Document;

import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;

@Document(collection="DefaultReport")
public class DefaultReport {
	
	private String username;
	private TemplateConfiguration commondata;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public TemplateConfiguration getCommondata() {
		return commondata;
	}
	public void setCommondata(TemplateConfiguration commondata) {
		this.commondata = commondata;
	}
	
	
	
}
