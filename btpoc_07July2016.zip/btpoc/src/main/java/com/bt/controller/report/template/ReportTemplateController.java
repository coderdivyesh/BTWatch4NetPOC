package com.bt.controller.report.template;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.common.CRUDOperation;
import com.bt.controller.report.ReportDataController;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.AllGlobalTemplate;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.GlobalReportTemplate;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.report.ReportTemplate;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.CollectionMetaData;
import com.bt.security.entity.UserVO;
import com.bt.security.helper.TokenHandler;
import com.bt.security.service.TokenAuthenticationConstant;
import com.bt.security.service.UserService;
import com.bt.service.report.ReportDataService;
import com.bt.service.report.template.ReportTemplateService;

@RestController
@RequestMapping("/api/report")
public class ReportTemplateController {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataController.class);

	@Autowired
	ReportTemplateService reportTemplateService;
	
	@Autowired
	ReportDataService reportdataservice;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getAllTemplate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportTemplate> getAllTemplates( @RequestHeader HttpHeaders header) {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllTemplate() : ");
		}
		ReportTemplate reportTemplate = new ReportTemplate();
		try {
			List<String> token=header.get(TokenAuthenticationConstant.AUTH_HEADER_NAME);
			String username=TokenHandler.parseUserNameFromToken(token.get(0));
			UserVO uservo=UserService.findUserByUsername(username);
			List<GlobalReportTemplate> globaltemplates = reportTemplateService.fetchAllGlobalTemplate();
			UserReportTemplate usertemplates = reportTemplateService.fetchUserTemplate(uservo.getUsername());
			AllGlobalTemplate globaltemplate=new AllGlobalTemplate();
			globaltemplate.setGlobaltemplates(globaltemplates);
			reportTemplate.setGlobaltemplate(globaltemplate);
			reportTemplate.setUsertemplate(usertemplates);
		} catch (Exception ex) {
			logger.error(" getAllTemplate() :" + ex.getMessage(), ex);
			return new ResponseEntity<ReportTemplate>(reportTemplate, HttpStatus.BAD_REQUEST);

		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllTemplate() : template : " + reportTemplate);
		}
		return new ResponseEntity<ReportTemplate>(reportTemplate, HttpStatus.OK);
	}
	
	/**
	 * This method will delete the user node and supported upto two levels 
	 * @param userreporttemplate
	 * @return
	 */
	
	@RequestMapping(value = "/insertUserTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserReportTemplate> insertUserTemplate(@RequestBody UserReportTemplate userreporttemplate) {
		DefaultReport defaultreport=null;
		if (null != userreporttemplate) {
			try {
				reportTemplateService.insertUserTemplate(userreporttemplate, CRUDOperation.INSERT);
				userreporttemplate=reportTemplateService.fetchUserTemplate(userreporttemplate.getUsername());
			} catch (Exception ex) {
				return new ResponseEntity<UserReportTemplate>(userreporttemplate, HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<UserReportTemplate>(userreporttemplate, HttpStatus.OK);
	}
	
	/**
	 * This method will delete the user node and supported upto two levels
	 * @param userreporttemplate
	 * @return 
	 */
	@RequestMapping(value = "/deleteUserTemplateNode", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserReportTemplate> deleteUserTemplateNode(
			@RequestBody UserReportTemplate userreporttemplate) {
		UserReportTemplate existingnode = null;
		if (null != userreporttemplate) {
			try {
				existingnode = reportTemplateService.deleteUserNode(userreporttemplate,CRUDOperation.DELETE);
			} catch (Exception ex) {
				return new ResponseEntity<UserReportTemplate>(userreporttemplate, HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<UserReportTemplate>(existingnode, HttpStatus.OK);
	}
	
	// For Global Report Template
	@RequestMapping(value = "/insertGlobalTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GlobalReportTemplate> insertGlobalTemplate(@RequestBody GlobalReportTemplate globalreporttemplate) {
		if (null != globalreporttemplate) {
			try {
				List<GlobalReportTemplate> globaltemplates = reportTemplateService.fetchAllGlobalTemplate();
				reportTemplateService.insertGlobalTemplate(globalreporttemplate,globaltemplates,CRUDOperation.INSERT);
			} catch (Exception ex) {
			return	new ResponseEntity<GlobalReportTemplate>(globalreporttemplate, HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<GlobalReportTemplate>(globalreporttemplate, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteGlobalTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<GlobalReportTemplate>> deleteGlobalTemplate(@RequestBody GlobalReportTemplate globalreporttemplate) {
		List<GlobalReportTemplate> existingTemplates = null;
		if (null != globalreporttemplate) {
			try {
				 existingTemplates = reportTemplateService.deleteGlobalTemplate(globalreporttemplate,CRUDOperation.DELETE);
			} catch (Exception ex) {
				return new ResponseEntity<List<GlobalReportTemplate>>(existingTemplates, HttpStatus.BAD_REQUEST);
				
			}
		}
		return new ResponseEntity<List<GlobalReportTemplate>>(existingTemplates, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/saveUserTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportDataList> saveUserTemplate(@RequestBody UserReportTemplate userreporttemplate) {
		ReportDataList reportlist = new ReportDataList();
		if (null != userreporttemplate) {
			try {
				//userreporttemplate.getNode().setFilterExpression("ClassName=BT_Switch#AND#ElementClassName=BT_Switch#AND#ElementName=20442222");
				TemplateConfiguration templateconfig = new TemplateConfiguration();
				reportTemplateService.updateUserTemplate(userreporttemplate,templateconfig);
				//Added for Testing purpose
				//userreporttemplate.getNode().setDuration("5month");
				templateconfig.setNode(userreporttemplate.getNode());
				templateconfig.setPagenumber(1);
				List<ReportData> reportdatalist = reportdataservice.getAllReportsAccoringtoTemplate(templateconfig);
				reportlist.setReportdatalist(reportdatalist);
				CommonData commondata = new CommonData();
				reportlist.setCommondata(commondata);
				commondata.setPagesize(userreporttemplate.getNode().getPagesize());
				commondata.setDuration(userreporttemplate.getNode().getDuration());
				commondata.setDisplayprams(userreporttemplate.getNode().getColumns());
			} catch (Exception e) {
				return new ResponseEntity<ReportDataList>(reportlist, HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<ReportDataList>(reportlist, HttpStatus.OK);
	}
	

}
