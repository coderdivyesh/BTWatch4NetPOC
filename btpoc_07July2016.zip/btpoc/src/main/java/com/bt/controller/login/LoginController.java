package com.bt.controller.login;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.common.BTContext;
import com.bt.common.CommonConstant;
import com.bt.dao.user.UserDAO;
import com.bt.entity.template.CollectionMetaData;
import com.bt.security.entity.UserVO;
import com.bt.security.service.TokenAuthenticationConstant;
import com.bt.security.service.TokenAuthenticationService;
import com.bt.security.service.UserActive;
import com.bt.security.service.UserAuthentication;
import com.bt.security.service.UserService;
import com.bt.service.metadata.MetaDataService;

//import com.bt.service.user.UserService;

import com.bt.service.report.template.ReportTemplateService;


@RestController
@RequestMapping("/api")
public class LoginController implements CommonConstant{
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	UserService userservice;
	
	@Autowired
	private UserDAO userDAO;

	@Autowired
	TokenAuthenticationService tokenAuthenticationService;
	//UserService is interface over here for insert data
	@Autowired
	com.bt.service.user.UserService userserviceActual;
	

	@Autowired
	ReportTemplateService reportTemplateservice;
	
  	 @Autowired
  	 MetaDataService collectionmetadata;
	

	@RequestMapping(value = "/login", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserVO> login() throws Exception  {

		UserVO uservo = null;
	    List<String> token = null;
		HttpHeaders header = new HttpHeaders();
		String username = null;
		if (SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {
			if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() instanceof UserVO) {
				uservo = (UserVO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				UserAuthentication userauth = new UserAuthentication(uservo);
				userauth.setAuthenticated(Boolean.TRUE);
				tokenAuthenticationService.addAuthentication(header, userauth);
				// insert into db tokenid + username
                token = header.get(TokenAuthenticationConstant.AUTH_HEADER_NAME);
                username = userauth.getName();
                UserActive uactive = new UserActive();
                uactive.setTokenId(token.get(0));
                uactive.setUsername(username);
                UserActive fetchDataDb =  userDAO.fetchActiveUsersInDb(uactive);
                if(null!=fetchDataDb){
                	if (StringUtils.isEmpty(fetchDataDb.getTokenId()) || StringUtils.isEmpty(fetchDataDb.getUsername())) { 
                		userserviceActual.insertToken(uactive);
                	}
                	else if((fetchDataDb.getUsername().equals(uactive.getUsername())) && (!fetchDataDb.getTokenId().equals(uactive.getTokenId())) )
                	{
                		userDAO.updateActiveUsers(uactive);
                	}
                }
                //Need to remove this code after proper implementation of metadata type
                CollectionMetaData metadtaForColection= collectionmetadata.loadMetaData(DEFAULT_COLLECTION_NAME);
                BTContext.putValueToApplicationMap(COLLECTION_METADATA_KEY, metadtaForColection);
				
			}
		}
		return new ResponseEntity<UserVO>(uservo, header,HttpStatus.OK);
	}
	
}

//}
