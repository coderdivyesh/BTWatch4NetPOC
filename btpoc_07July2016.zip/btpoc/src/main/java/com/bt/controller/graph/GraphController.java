package com.bt.controller.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;
import com.bt.entity.template.NodeColumn;
import com.bt.service.graph.GraphService;

/**
 * 
 * @author 611022088
 *
 */
@RestController
@RequestMapping("/graph")
public class GraphController {
	private static final Logger logger = LoggerFactory.getLogger(GraphController.class);

	@Autowired
	GraphService graphService;

	/**
	 * Get JSON response from table
	 * 
	 * @param xparam
	 * @param yparam
	 * @param duration
	 * @param samplingPeriod
	 * @param aggrType
	 * @return
	 */

	@RequestMapping(value = "/getChart/{xparam}/{yparam}/{duration}/{samplingPeriod}/{aggrType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getAllGraphReports(@PathVariable String xparam, @PathVariable String yparam,
			@PathVariable String duration, @PathVariable String samplingPeriod, @PathVariable String aggrType) {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : ");
		}
		StringBuilder json = new StringBuilder("[");
		if (StringUtils.isEmpty(xparam) && StringUtils.isEmpty(yparam)) {
			new ResponseEntity<String>(json.toString(), HttpStatus.BAD_REQUEST);
		} else {
			CommonData commondata = populateCommondata(xparam, yparam, duration, samplingPeriod, aggrType, null, null,
					1, 100);
			try {
				GraphDetails graphDetails = graphService.fetchGraphdata(commondata);
				Map<String, Object> graphvalues = graphDetails.getGraphvalues();
				formJSON(json, graphDetails, graphvalues, aggrType);
				json.deleteCharAt(json.lastIndexOf(","));
				json.append("]");
			} catch (Exception ex) {
				logger.error(" getAllGraphReports() " + ex.getMessage(), ex);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: ");
		}
		return new ResponseEntity<String>(json.toString(), HttpStatus.OK);
	}

	/**
	 * create a json string
	 * 
	 * @param json
	 * @param graphDetails
	 * @param graphvalues
	 * @param aggrType 
	 */
	private void formJSON(StringBuilder json, GraphDetails graphDetails, Map<String, Object> graphvalues, String aggrType) {

		for (Map.Entry<String, Object> entry : graphvalues.entrySet()) {
			String xvalueString = null;
			String yvalueString = null;
			Object yvalue = null;
			if (!StringUtils.isEmpty(entry.getKey())) {
				xvalueString = entry.getKey();
				yvalue = entry.getValue();
				if (yvalue.getClass().isAssignableFrom(Integer.class)
						|| yvalue.getClass().isAssignableFrom(Double.class)) {
					yvalueString = String.valueOf(yvalue);
				} else {
					yvalueString = "\"" + yvalue + "\"";
				}
				
				if (aggrType.equals("count")) {
					json.append("{\"" + graphDetails.getXfieldName() + "\":").append(xvalueString + ",")
					.append("\"Count\":").append(yvalueString + "},");
				} else {
					json.append("{\"" + graphDetails.getXfieldName() + "\":").append(xvalueString + ",")
					.append("\"" + graphDetails.getYfieldName() + "\":").append(yvalueString + "},");
				}
				
				
				/*json.append("{\"name\":").append(xvalueString + ",")
				  .append("\"y\":").append(yvalueString + "},");*/
			}
		}
	}

	/**
	 * Prepare CommonData
	 * 
	 * @param xparam
	 * @param yparam
	 * @param duration
	 * @param samplingPeriod
	 * @param aggrType
	 * @param starttime
	 * @param endtime
	 * @param pagenumber
	 * @param pagesize
	 * @return
	 */

	private CommonData populateCommondata(String xparam, String yparam, String duration, String samplingPeriod,
			String aggrType, String starttime, String endtime, int pagenumber, int pagesize) {
		CommonData commondata = new CommonData();
		commondata.setDuration(duration);
		commondata.setSamplingPeriod(samplingPeriod);
		commondata.setAggrType(aggrType);
		commondata.setStarttime(starttime);
		commondata.setEndtime(endtime);
		commondata.setPagenumber(pagenumber);
		commondata.setPagesize(pagesize);
		List<NodeColumn> listofdisplay = new ArrayList<NodeColumn>();
		NodeColumn xdisplay = new NodeColumn();
		xdisplay.setName(xparam.toLowerCase());
		xdisplay.setDbname(xparam);
		xdisplay.setLabel(xparam.toUpperCase());
		listofdisplay.add(xdisplay);

		NodeColumn ydisplay = new NodeColumn();
		ydisplay.setName(yparam.toLowerCase());
		ydisplay.setDbname(yparam);
		ydisplay.setLabel(yparam.toUpperCase());
		listofdisplay.add(ydisplay);
		commondata.setDisplayprams(listofdisplay);
		return commondata;
	}

}
