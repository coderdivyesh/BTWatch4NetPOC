package com.bt.controller.report;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.common.BTContext;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.template.ExpressionDetails;
import com.bt.service.report.ReportDataService;

@RestController
@RequestMapping("/api/report")
public class ReportDataController {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataController.class);

	@Autowired
	ReportDataService reportDataService;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getAllReports", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports() {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : ");
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports();
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	/**
	 * 
	 * @param pagenumber
	 * @param pagesize
	 * @param lastid
	 * @return
	 */
	@RequestMapping(value = "/getAllReportwithPageination/{pagenumber}/{pagesize}/{lastid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports(@PathVariable int pagenumber, @PathVariable int pagesize,
			@PathVariable int lastid) {
		if (logger.isDebugEnabled()) {
			logger.debug(getAllReports() + " Page Number : " + pagenumber + " Page Size : " + pagesize);
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports(pagenumber, pagesize);
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	/**
	 * 
	 * @param reportData
	 * @return
	 */

	@RequestMapping(value = "/getReportsAccordingTemplate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportDataList> getReportsAccordingTemplate(@RequestBody TemplateConfiguration templateconfiguration) {
		if (logger.isDebugEnabled()) {
			logger.debug("getReportsForTemplate() CommonData  ");
		}
		ReportDataList reportlist = new ReportDataList();
		if(null !=templateconfiguration )
		{
		try {
				Map<String, ExpressionDetails> expressionmap = (Map<String, ExpressionDetails>) BTContext
						.getValueFromApplicationMap(templateconfiguration.getNode().getId());
				templateconfiguration.setExpressionmap(expressionmap);
				List<ReportData> reportdatalist = reportDataService
						.getAllReportsAccoringtoTemplate(templateconfiguration);
				reportlist.setReportdatalist(reportdatalist);
				CommonData commondata = new CommonData();
				reportlist.setCommondata(commondata);
				commondata.setPagesize(templateconfiguration.getNode().getPagesize());
				commondata.setDuration(templateconfiguration.getNode().getDuration());
				commondata.setPagenumber(templateconfiguration.getPagenumber());
				commondata.setDisplayprams(templateconfiguration.getNode().getColumns());
				commondata.setTotalrecordCount(templateconfiguration.getTotalRecordCount());
		} catch (Exception ex) {
			logger.error(" Unable to process request :" + ex.getMessage(), ex);
			return new ResponseEntity<ReportDataList>(reportlist, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		}
		return new ResponseEntity<ReportDataList>(reportlist, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getsortdata/{columnName}/{flag}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getsortdata(@PathVariable String columnName, @PathVariable int flag) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug(" sortData() : ");
		}
		List<ReportData> sortReportDataList = reportDataService.getsortReport(columnName,flag);
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + sortReportDataList);
		}
		return new ResponseEntity<List<ReportData>>(sortReportDataList, HttpStatus.OK);
	}
	
	

}
