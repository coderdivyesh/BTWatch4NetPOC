package com.bt.controller.metadata;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.common.BTContext;
import com.bt.common.CommonConstant;
import com.bt.controller.report.ReportDataController;
import com.bt.entity.template.CollectionMetaData;
import com.bt.security.entity.UserVO;
import com.bt.security.helper.TokenHandler;
import com.bt.security.service.TokenAuthenticationConstant;
import com.bt.security.service.UserService;
import com.bt.service.metadata.MetaDataService;

@RestController
@RequestMapping("api/metadata")
public class CollectionMetaDataController {
	private static final String DEFAULT_COLLECTION_NAME = "testing2";

	private static final Logger logger = LoggerFactory.getLogger(ReportDataController.class);
	
	 @Autowired
	 MetaDataService collectionmetadata;
	 
	 
	/**
	 * 
	 * @param header
	 * @return
	 */
	@RequestMapping(value = "/getCollectionMetaData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CollectionMetaData> fetchTableMetaData( @RequestHeader HttpHeaders header) {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllTemplate() : ");
		}
		CollectionMetaData tableMetaData = new CollectionMetaData();
		try {
			List<String> token = header.get(TokenAuthenticationConstant.AUTH_HEADER_NAME);
			String username = TokenHandler.parseUserNameFromToken(token.get(0));
			UserVO uservo = UserService.findUserByUsername(username);
			if (null != uservo) {
				tableMetaData=(CollectionMetaData) BTContext.getValueFromApplicationMap(CommonConstant.COLLECTION_METADATA_KEY);
				if(null==tableMetaData){
				tableMetaData = collectionmetadata.loadMetaData(DEFAULT_COLLECTION_NAME);
				BTContext.putValueToApplicationMap(CommonConstant.COLLECTION_METADATA_KEY, tableMetaData);
				}
			} else {
				return new ResponseEntity<CollectionMetaData>(tableMetaData, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
			}

		} catch (Exception ex) {
			logger.error(" getAllTemplate() :" + ex.getMessage(), ex);
			return new ResponseEntity<CollectionMetaData>(tableMetaData, HttpStatus.BAD_REQUEST);

		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllTemplate() : template : " + tableMetaData);
		}
		return new ResponseEntity<CollectionMetaData>(tableMetaData, HttpStatus.OK);
	}

}
