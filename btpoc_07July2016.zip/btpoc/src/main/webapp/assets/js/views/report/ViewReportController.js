
angular.module('reportTool').controller('ViewReportController',['$scope','$http','ViewReportService','$sce','$location','$state','ManageDivService','AppConstants','$sessionStorage','$window', function($scope, $http ,ViewReportService,$sce,$location,$state,ManageDivService,AppConstants,$sessionStorage,$window)  {


	$scope.filterExpression='';
	$scope.loading = true;
	$scope.error1=false;
	$scope.pagenumber=1;
	$scope.pagetotalsize=100;
	$scope.totalRecordCount='';
	$scope.formats = ["XLS", "CSV","TXT","PDF"];
	$scope.lastid=1;
	$scope.data='';

	$scope.enableDisplayOptions = false;
	$scope.timeIntervals = ["past 15 min" ,"past 30 min", "past 1 day" ,"past 1 week","past 1 month" ,"past 3 month","past 4 month","past 5 month","past 6 month","past 1 year"];
	$scope.durationIntervals = ["past 1 hour", "past 1 day", "past 1 week", "past 1 month", "past quarter", "past half year", "past 1 year"];
	$scope.samplingPeriodIntervals = ["15 min" ,"30 min", "1 hour", "6 hours", "1 day" ,"1 week","1 month", "quarter", "half year"];
	$scope.aggrTypes = ["sum" , "avg", "min", "max", "count"];
	$scope.chartOptions = ["Column Chart" ,"Bar Chart", "Line Chart", "Pie Chart"];
	$scope.operatorList=AppConstants.FilterExpressionEnum;
	$scope.conditionalOperatorList=[{key:'AND',value:'#AND#'},{key:'OR',value:'#OR#'}];
	$scope.input=[];
	$scope.min=0;
	$scope.max=15;
	$scope.duration='1day';
	$scope.xValue='OpenedAt';
	$scope.yValue='Duration';
	$scope.graphDuration='1day';
	$scope.samplingPeriod='1hour';
	$scope.aggrType='sum';
	$scope.chartType='column';
	$scope.starttime=null;
	$scope.endtime=null;
	$scope.filterObjects=[];
	$scope.showCondition=false;
	$scope.selectedConditionalOp=$scope.conditionalOperatorList[0];
	$scope.columns =[];
	$scope.tableColumns1=[];
	$scope.date = new Date();

	$scope.username='';
	$scope.templtid='';
	$scope.reportParentId='';
	$scope.reportId='';
	$scope.content='';
	$scope.pageCountList = [10,20,30,40,50,60,70,80,90,100];
	$scope.newReportName='';
	$scope.newReportPagesize='';
	$scope.request={};

	$scope.defaultpageCount=10;
	$scope.pagesize=10;
	$scope.selectedpageCount=10;

	$scope.totalPagedisplaySize = 10;

	$scope.records=[{id:1}];

	$scope.range=[];
	$scope.emailId='';
	$scope.attachmentType='';

	$scope.totalPagedisplaySize = Math.ceil(100 / $scope.selectedpageCount);

	var matchfound=false;
	var isFolder=false;
	$scope.showResultMessage=false;
	$scope.resultMessage='';
	$scope.displayfilterExpression='';
	
	$scope.CurrentNode = '';
	$scope.SelectedNode='';

	
    var callMethod=true;
	var range = [];
	for(var i=1;i<=$scope.totalPagedisplaySize;i++) {
		range.push(i);
	}
	$scope.range = range;

	$scope.globadata='';
	$scope.globaltemplatetree='';
	$scope.usertemplatetree ='';
	$scope.globaltreedata = '';


	$scope.request.username=$scope.username;
	$scope.request.id=$scope.templtid;

	$scope.nodelevel='';

	ManageDivService.setDefaultdivValues($scope);

	$scope.request.node=
	{
			duration:$scope.duration,
			id:$scope.reportId,
			parentid:$scope.reportParentId,
			columns:$scope.columns

	};

	$scope.temporaryNode = {
			nodes: []
	};

	

	$scope.newReport = {
			tabcolumns:[]

	};

	//graph
	$scope.xParamTableColumns = [
	                             {name:'openedat',label:'OPENEDAT',dbname:'OpenedAt'},
	                             {name:'closedat',label:'CLOSEDAT',dbname:'ClosedAt'},
	                             {name:'updatedat',label:'UPDATEAT',dbname:'UpdatedAt'}
	                             ];
	//graph
	$scope.yParamTableColumns=[
	                           {name:'duration',label:'DURATION',dbname:'Duration'},
	                           {name:'certainty',label:'CERTAINITY',dbname:'Certainty'},
	                           {name:'severity',label:'SEVERITY',dbname:'Severity'},
	                           {name:'isroot',label:'ISROOT',dbname:'IsRoot'},
	                           {name:'isproblem',label:'ISPROBLEM',dbname:'IsProblem'},
	                           {name:'acknowledged',label:'ACKNOWLEDGED',dbname:'Acknowledged'},
	                           {name:'classname',label:'CLASSNAME',dbname:'ClassName'},
	                           {name:'eventname',label:'EVENT_NAME',dbname:'Eventname'},
	                           {name:'classdisplayname',label:'CLASS_DISPLAY_NAME',dbname:'ClassDisplayName'},
	                           {name:'eventdisplayname',label:'EVENT_DISPLAY_NAME',dbname:'EventDisplayName'},
	                           {name:'elementclassname',label:'ELEMENT_CLASS_NAME',dbname:'ElementClassName'},
	                           {name:'sourceeventtype',label:'SOURCE_EVENTTYPE',dbname:'SourceEventtype'},
	                           {name:'eventtype',label:'EVENTTYPE',dbname:'EventType'},
	                           {name:'owner',label:'OWNER',dbname:'Owner'},
	                           {name:'userdefined1',label:'USERDEFINED1',dbname:'UserDefined1'}
	                           ];

	

/*	$scope.tableColumns1=[
	                      {name:'id',label:'ID',dbname:'_id',datatype:'',friendlyname:''},
	                      {name:'name',label:'NAME',dbname:'Name',datatype:'',friendlyname:''},
	                      {name:'openedat',label:'OPENEDAT',dbname:'OpenedAt',datatype:'',friendlyname:''},
	                      {name:'source',label:'SOURCE',dbname:'Source',datatype:'',friendlyname:''},
	                      {name:'classname',label:'CLASSNAME',dbname:'ClassName',datatype:'',friendlyname:''},
	                      {name:'instancename',label:'INSTANCE_NAME',dbname:'InstanceName',datatype:'',friendlyname:''},
	                      {name:'eventname',label:'EVENT_NAME',dbname:'Eventname',datatype:'',friendlyname:''},
	                      {name:'classdisplayname',label:'CLASS_DISPLAY_NAME',dbname:'ClassDisplayName',datatype:'',friendlyname:''},
	                      {name:'instancedisplayname',label:'INSTANCE_DISPLAY_NAME',dbname:'InstanceDisplayName',datatype:'',friendlyname:''},
	                      {name:'eventdisplayname',label:'EVENT_DISPLAY_NAME',dbname:'EventDisplayName',datatype:'',friendlyname:''},
	                      {name:'elementclassname',label:'ELEMENT_CLASS_NAME',dbname:'ElementClassName',datatype:'',friendlyname:''},
	                      {name:'elementname',label:'ELEMENT_NAME',dbname:'ElementName',datatype:'',friendlyname:''},
	                      {name:'sourcedomainname',label:'SOURCE_DOMAINNAME',dbname:'SourcedomainName',datatype:'',friendlyname:''},
	                      {name:'sourceeventtype',label:'SOURCE_EVENTTYPE',dbname:'SourceEventtype',datatype:'',friendlyname:''},
	                      {name:'active',label:'ACTIVE',dbname:'Active',datatype:'',friendlyname:''},
	                      {name:'closedat',label:'CLOSEDAT',dbname:'ClosedAt',datatype:'',friendlyname:''},
	                      {name:'lastchangedat',label:'LAST_CHANEDDATE',dbname:'',datatype:'',friendlyname:''},
	                      {name:'isroot',label:'ISROOT',dbname:'',datatype:'',friendlyname:''},
	                      {name:'isproblem',label:'ISPROBLEM',dbname:'',datatype:'',friendlyname:''},
	                      {name:'eventtype',label:'EVENTTYPE',dbname:'',datatype:'',friendlyname:''},
	                      {name:'severity',label:'SEVERITY',dbname:'',datatype:'',friendlyname:''},
	                      {name:'impact',label:'IMPACT',dbname:'',datatype:'',friendlyname:''},
	                      {name:'certainty',label:'CERTAINITY',dbname:'Certainty',datatype:'',friendlyname:''},
	                      {name:'inMaintenance',label:'INMAINTATINANCE',dbname:'',datatype:'',friendlyname:''},
	                      {name:'troubleticketiD',label:'TROUBLE_TICKETID',dbname:'',datatype:'',friendlyname:''},
	                      {name:'owner',label:'OWNER',dbname:'',datatype:'',friendlyname:''},
	                      {name:'updatedat',label:'UPDATEAT',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined1',label:'USERDEFINED1',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined2',label:'USERDEFINED2',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined3',label:'USERDEFINED3',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined4',label:'USERDEFINED4',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined5',label:'USERDEFINED5',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined6',label:'USERDEFINED6',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined7',label:'USERDEFINED7',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined8',label:'USERDEFINED8',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined9',label:'USERDEFINED9',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined10',label:'USERDEFINED10',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined11',label:'USERDEFINED11',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined12',label:'USERDEFINED12',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined13',label:'USERDEFINED13',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined14',label:'USERDEFINED14',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined15',label:'USERDEFINED15',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined16',label:'USERDEFINED16',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined17',label:'USERDEFINED17',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined18',label:'USERDEFINED18',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined19',label:'USERDEFINED19',dbname:'',datatype:'',friendlyname:''},
	                      {name:'userdefined20',label:'USERDEFINED20',dbname:'',datatype:'',friendlyname:''}
	                      ];
*/



	$scope.$watch('selection', function(newVal, oldVal){
		switch(newVal){
		case 'XLS':
		{
			ViewReportService.loadXLSData($scope.request).success(function(data, status) {
				var xlsinput = new Blob([data],{ type: 'application/vnd.ms-excel' }); 
				window.navigator.msSaveOrOpenBlob(xlsinput, 'report.xls'); 
			});
		};
		break;
		case 'CSV':
		{
			ViewReportService.loadCSVData($scope.request).success(function(data, status) {
				var csvinput = new Blob([data],{ type: 'application/csv' }); 
				window.navigator.msSaveOrOpenBlob(csvinput, 'report.csv'); 
			});
		};
		break;
		case 'PDF':
		{
			ViewReportService.loadPDFData($scope.request).success(function(data, status) {
				var file = new Blob([data],{ type: 'application/pdf' }); 
				window.navigator.msSaveOrOpenBlob(file, 'report.pdf');        

			});
		};
		break;
		default:
			break;
		}
	});

	$scope.loadtreedata= function() {
		ViewReportService.getTreeData($scope).success(function(data, status) {
			$scope.loading = true;
			if(data == "")
			{
				console.log("The request failed with no response  and status code " + status);
				$scope.loading = false;
				$scope.error1 = "Invalid Session !! Please Login Again !!";

			}
			$scope.tableColumns1=$sessionStorage.tableMetaData.columns;
			$scope.globaltreedata = data.globaltemplate.globaltemplates;
			$scope.setTreeData(data.globaltemplate.globaltemplates,data.usertemplate);
			$scope.loading = false;
			console.log(" $scope.globaltreedata.length " +$scope.globaltreedata.length);
			for(var i= 0 ;i<$scope.globaltreedata.length;i++)
			{ 
				if($scope.globaltreedata[i].node != null)
					$scope.globaltreedata[i].node.nodelevel=i+1;
				$scope.setNodeLevel($scope.globaltreedata[i].nodes,i+1);
			}
		}).error(function(response, status) {  
			console.log("The request failed with response " + response + " and status code " + status);
			$scope.loading = false;

		});

	};

	$scope.setTreeData = function(globaltemplates ,usertemplate){
		$scope.usertemplatetree=usertemplate;
		$scope.globadata=globaltemplates;
		$scope.globaltreedata= $scope.globadata.concat($scope.usertemplatetree);
		$scope.username=usertemplate.username;
		$scope.templtid=usertemplate.id;
		
	}

	$scope.showReport = function(node)
	{
		$scope.CurrentNode=node;
		$scope.SelectedNode=node;
		//set value in show
		callMethod=false;
	 	$scope.selectedpageCount=node.$nodeScope.$modelValue.pagesize;
		$scope.defaultpageCount=node.$nodeScope.$modelValue.pagesize;
		$scope.duration=node.$nodeScope.$modelValue.duration;
		ManageDivService.enableReportAddOptions(true,$scope);
		if(node.$nodeScope.$parentNodeScope != null)
		{	$scope.reportParentId=node.$nodeScope.$parentNodeScope.$modelValue.id;}
		else
		{$scope.reportParentId=null; }
		
		$scope.reportId=node.$nodeScope.$modelValue.id;
		$scope.columns=node.$nodeScope.$modelValue.columns;
		
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableShowReportView(true,$scope);

		$scope.request.pagenumber=$scope.pagenumber;
		$scope.request.node={pagesize:node.$nodeScope.$modelValue.pagesize,duration:$scope.duration,id:$scope.reportId ,parentid:$scope.reportParentId,columns:$scope.columns};

		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records=data.reportdatalist;
			$scope.tableColumns=data.commondata.displayprams;
			$scope.newReport.tabcolumns=data.commondata.displayprams;
			$scope.defaultpageCount=node.$nodeScope.$modelValue.pagesize;
			callMethod=true;
			if($scope.pagenumber==1)
			{$scope.totalRecordCount=data.commondata.totalrecordCount;}
		});
	};

	$scope.nextPage = function() {
		if ($scope.pagenumber < $scope.pagetotalsize) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber++;
			$scope.displayNewReportTab=false;
			$scope.displayGraph=false;
			if($scope.pagenumber > $scope.range.length)
			{
				$scope.range.push($scope.pagenumber);
			}
			ViewReportService.showReport($scope.CurrentNode).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				$scope.newReport.tabcolumns=data.commondata.displayprams;
			});
		}
		else
			$scope.disableNext =true;
	};

	$scope.previousPage = function() {
		if ($scope.pagenumber > 1) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber--;
			$scope.displayNewReportTab=false;
			$scope.displayGraph=false;

			ViewReportService.showReport($scope.CurrentNode).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				$scope.newReport.tabcolumns=data.commondata.displayprams;
			});
		}else
			$scope.disablePrevious = true;
	};

	$scope.$watch('selectedpageCount', function(){
		$scope.defaultpageCount=$scope.selectedpageCount;
		$scope.pagesize=$scope.selectedpageCount;
		$scope.CurrentNode.$nodeScope.$modelValue.pagesize=$scope.selectedpageCount;
		if(callMethod==true)
		{$scope.showReport($scope.CurrentNode);}
		
	});

	$scope.exportData = function () {
		alasql('SELECT * INTO CSV("records.csv",{headers:true}) FROM ?',[$scope.records]);
	};

	$scope.displayOptions = function(){
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableShowReportView(true,$scope);
		ManageDivService.enabledisplayOptionView(true,$scope);
	}

	$scope.$watch('timeIntervalselection', function(newVal, oldVal){
		switch(newVal){
		case 'past 15 min':
		{
			$scope.duration="15minutes";
		};
		break;
		case 'past 30 min':
		{
			$scope.duration="30minutes";
		};
		break;
		case 'past 1 day':
		{
			$scope.duration="1day";
		};
		break;
		case 'past 1 week':
		{
			$scope.duration="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.duration="1month";
		};
		break;
		case 'past 4 month':
		{
			$scope.duration="4month";
		};
		break;
		case 'past 5 month':
		{
			$scope.duration="5month";
		};
		break;
		case 'past 6 month':
		{
			$scope.duration="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.duration="1year";
		};
		break;
		default:
			return;
		}
		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.filterParameter;
			$scope.newReport.tabcolumns=data.commondata.displayprams;
		});
	});

	$scope.$watch('graphDurationIntervalSelection', function(newVal, oldVal){
		switch(newVal){
		case 'past 1 hour':
		{
			$scope.graphDuration="1hour";
		};
		break;
		case 'past 1 day':
		{
			$scope.graphDuration="1day";
		};
		break;
		case 'past 1 week':
		{
			$scope.graphDuration="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.graphDuration="1month";
		};
		break;
		case 'past quarter':
		{
			$scope.graphDuration="3month";
		};
		break;
		case 'past half year':
		{
			$scope.graphDuration="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.graphDuration="1year";
		};
		break;
		default:
			break;
		}
	});

	$scope.$watch('graphSamplingPeriodSelection', function(newVal, oldVal){
		switch(newVal){
		case '15 min':
		{
			$scope.samplingPeriod="15minutes";
		};
		break;
		case '30 min':
		{
			$scope.samplingPeriod="30minutes";
		};
		break;
		case '1 hour':
		{
			$scope.samplingPeriod="1hour";
		};
		break;
		case '6 hours':
		{
			$scope.samplingPeriod="6hour";
		};
		break;
		case '1 day':
		{
			$scope.samplingPeriod="1day";
		};
		break;
		case '1 week':
		{
			$scope.samplingPeriod="1week";
		};
		break;
		case '1 month':
		{
			$scope.samplingPeriod="1month";
		};
		break;
		case 'quarter':
		{
			$scope.samplingPeriod="3month";
		};
		break;
		case 'half year':
		{
			$scope.samplingPeriod="6month";
		};
		break;
		default:
			break;
		}

	});

	$scope.$watch('graphAggregationTypeSelection', function(newVal, oldVal){
		switch(newVal){
		case 'sum':
		{
			$scope.aggrType="sum";
		};
		break;
		case 'avg':
		{
			$scope.aggrType="avg";
		};
		break;
		case 'min':
		{
			$scope.aggrType="min";
		};
		break;
		case 'max':
		{
			$scope.aggrType="max";
		};
		break;
		case 'count':
		{
			$scope.aggrType="count";
		};
		break;
		default:
			break;
		}
	});

	$scope.$watch('graphChartTypeSelection', function(newVal, oldVal){
		switch(newVal){
		case 'Column Chart':
		{
			$scope.chartType="column";
		};
		break;
		case 'Bar Chart':
		{
			$scope.chartType="bar";
		};
		break;
		case 'Line Chart':
		{
			$scope.chartType="line";
		};
		break;
		case 'Pie Chart':
		{
			$scope.chartType="pie";
		};
		break;
		default:
			break;
		}
	});


	$scope.getReportbyPage= function(pagNo)
	{
		$scope.pagenumber = pagNo;
		$scope.showReport($scope.CurrentNode);
	};

	$scope.activePageClass = function (page) {
		if(page == $scope.pagenumber)
		{
			return 'active';
		}
	};

	$scope.getNewReportScreen = function(data)
	{
		$scope.newReport.tabcolumns=data.node.columns;
		$scope.newReportTimeInterval=data.node.duration;
		$scope.newReportPagesize=data.node.pagesize;
		if(data.node.filterExpression == null)
		   $scope.filterExpression ='';
		else
		$scope.filterExpression=data.node.filterExpression;
		
		$scope.displayfilterExpression =$scope.filterExpression;
		
		
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableNewReportView(true,$scope);
	};

	$scope.saveNewReport = function(){
		
		

		$scope.request.username=$scope.username;
		$scope.request.id=$scope.templtid;

		switch($scope.newReportTimeInterval){
		case 'past 15 min':
		{
			$scope.newReportTimeInterval="15minutes";
		};
		break;
		case 'past 30 min':
		{
			$scope.newReportTimeInterval="30minutes";
		};
		break;
		case 'past 1 day':
		{
			$scope.newReportTimeInterval="1day";
		};
		break;r
		case 'past 1 week':
		{
			$scope.newReportTimeInterval="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.newReportTimeInterval="1month";
		};
		break;
		case 'past 3 month':
		{
			$scope.newReportTimeInterval="3month";
		};
		break;
		case 'past 4 month':
		{
			$scope.newReportTimeInterval="4month";
		};
		break;
		case 'past 5 month':
		{
			$scope.newReportTimeInterval="5month";
		};
		break;
		case 'past 6 month':
		{
			$scope.newReportTimeInterval="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.newReportTimeInterval="1year";
		};
		break;
		default:
			break;
		}


		$scope.request.node=
		{
				parentid:$scope.reportParentId, 
				id:$scope.reportId,
				label:$scope.newReportName,
				columns:$scope.newReport.tabcolumns,
				label:$scope.newReportName,
				pagesize:$scope.newReportPagesize,
				duration:$scope.newReportTimeInterval,
				filterExpression:$scope.filterExpression,
				nodelevel:$scope.nodelevel


		};
		$scope.CurrentNode.$nodeScope.$modelValue.label=$scope.newReportName;
		$scope.SelectedNode.$nodeScope.$modelValue.label=$scope.newReportName;
		$scope.CurrentNode.$nodeScope.$modelValue.pagesize=$scope.newReportPagesize;
		$scope.CurrentNode.$nodeScope.$modelValue.duration=$scope.newReportTimeInterval;
		/*//update new report Name on UI
		for(var i= 0 ;i<$scope.globaltreedata.length;i++)
		{
			var depth=i+1;
			$scope.recursiveSearch($scope.globaltreedata[i].nodes,'id',$scope.reportId,depth,'label',$scope.newReportName);
		}	*/

		//if role is admin then report will be save as gobal template in db
		if($sessionStorage.role == AppConstants.RoleEnum['admin'])
			{
			
			}
		
		else{
			
			
			$scope.loading=true;
		ViewReportService.saveNewReport($scope.request).success(function(data, status) {

					
			ManageDivService.setDefaultdivValues($scope);
			ManageDivService.enableShowReportView(true,$scope);
			$scope.selectedpageCount=$scope.newReportPagesize;
			$scope.defaultpageCount=$scope.selectedpageCount;
			$scope.duration=$scope.newReportTimeInterval;

			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.displayprams;
			$scope.newReport.tabcolumns=data.commondata.displayprams;
			$scope.CurrentNode.$nodeScope.$modelValue.columns=data.commondata.displayprams;
			$scope.pagenumber=1;
			console.log("data :- "+data);
			$scope.loading=false;
		});
		
		
		$scope.selectedConditionalOp='';
		$scope.selectedColumn='';
		$scope.selectedOp='';
		$scope.FilterValue='';
	
		
		}
		

	};


	$scope.savefilterExpression = function(){var operatorToSend={key:'',value:''};
    
    if($scope.showCondition == false)
    {
           operatorToSend.key='';
           operatorToSend.value='';
    }
    else
           {
           operatorToSend.key=$scope.selectedConditionalOp.key;
           operatorToSend.value=$scope.selectedConditionalOp.value;
           }
    $scope.showCondition=true;
    $scope.displayfilterExpression= $scope.displayfilterExpression+"    "+operatorToSend.key+"  "+$scope.selectedColumn+"  "  +$scope.selectedOp+ " " +$scope.FilterValue;
    
    $scope.filterExpression=$scope.filterExpression+($scope.filterExpression== ''?'':operatorToSend.value)+$scope.selectedColumn+$scope.selectedOp+$scope.FilterValue;

    console.log("$scope.filterExpression  "+$scope.filterExpression);
    
    $scope.selectedColumn='';
    $scope.selectedOp='';
    $scope.FilterValue='';
}

	$scope.clearfilterExpression= function(){
		$scope.filterExpression='';
		$scope.displayfilterExpression='';
		$scope.selectedConditionalOp=$scope.conditionalOperatorList[1];
		$scope.showCondition=false;
	}


	$scope.constructRequestObj = function (mainObject)
	{
		mainObject.request.username=$scope.username;
		mainObject.request.id=$scope.templtid;

		mainObject.request.node=
		{
				pagesize:$scope.selectedpageCount,
				duration:$scope.duration,
				id:$scope.reportId,
				parentid:$scope.reportParentId,
				columns:$scope.columns,
				nodelevel:$scope.nodelevel,
				label:$scope.newReportName

		};
		return mainObject.request;
	}


	$scope.showGraph = function()
	{
		$scope.xValue='OpenedAt';
		$scope.yValue='Duration';
		$scope.graphDuration='1day';
		$scope.samplingPeriod='1hour';
		$scope.aggrType='sum';
		$scope.chartType='column';
		
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableGraphView(true,$scope);
		$scope.drawGraph();
	};	 
	$scope.drawGraph = function()
	{	
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableGraphView(true,$scope);	

		$scope.xCoordinate=$scope.xValue;
		$scope.yCoordinate=$scope.yValue;
		
		ViewReportService.drawGraph($scope).success(function(data, status, jqxhr) {
			var processed_json = new Array();
			var a;
			var b;

           data.sort(sortByProperty($scope.xCoordinate));			
           $.each(data, function() {
				var str = "";
				$.each(this, function(key, val){
					if(str.length==0) {
						str=str.concat(val);
						a=val;
					} else {
						str=str.concat(", ",val);
						b=val;
					}  
				});
				processed_json.push([a*1000, b]);
			});

			/*$.map(data, function(obj, i) {
					     processed_json.push([obj.OpenedAt, obj.ClosedAt]);
					 });*/

			var chart = new Highcharts.Chart({
				colors: ["#7cb5ec", "#f7a35c"],
				chart: {
					type: $scope.chartType,
					//type: 'bar',
					zoomType: 'xy',
					renderTo: 'viz'
				},
				title: {
					text: capitalizeFirstLetter($scope.chartType) + (" Chart")
				},
				xAxis: {
					type : 'datetime',
					title: {
						text: $scope.xCoordinate
					}
				},
				yAxis: {
					title: {
						text: $scope.yCoordinate
					}
				},
				series: [{
					data: processed_json
					//data: data
				}]
			});		 
		});
	};	 

	function capitalizeFirstLetter(string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}
	/**
	 * Generic array sorting
	 *
	 * @param property
	 * @returns {Function}
	 */
	var sortByProperty = function (property) {
	    return function (x, y) {
	        return ((x[property] === y[property]) ? 0 : ((x[property] > y[property]) ? 1 : -1));
	    };
	};
	
	

	$scope.setNodeLevel = function (nodes, depth)
	{
		var childrenNode = nodes;
		childrenNode.nodelevel=depth;

		if (childrenNode!=null && childrenNode.length>0){

			for (var i = 0; i < childrenNode.length; i++) {  
				if(i>0)
				{
					if(childrenNode[i].parentid == childrenNode[i-1].parentid)
					{
						depth=depth.substring(0,depth.lastIndexOf('.')) ;
						depth=depth+'.'+(i+1);
					}
					else
						depth=depth+'.'+(i+1);
				}
				else
					depth=depth+'.'+(i+1);

				console.log( "  set nodelevel   : children"  +childrenNode[i].label   +  "    "+ "" +" "   +  depth);

				$scope.setNodeLevel( childrenNode[i],depth);
				if(childrenNode[i].nodes!=null)
				{
					$scope.setNodeLevel( childrenNode[i].nodes,depth);
				}            

			}
		}
	}

	$scope.editReporttemplate = function(editNode)
	{
		var data={
				node:editNode.$nodeScope.$modelValue
		} 
		console.log(" data " + data);
		console.log(" data.node " + data.node);
		$scope.newReportName=editNode.$nodeScope.$modelValue.label;
		$scope.nodelevel=editNode.$nodeScope.$modelValue.nodelevel;
		$scope.newReport.tabcolumns=editNode.$nodeScope.$modelValue.columns;
	    
		$scope.getNewReportScreen(data);
	}
	
	
	$scope.remove = function (scope) {
		
		
		
		var deleteNode = $window.confirm('Are you sure you want to delete?');

		if (deleteNode) {

		ManageDivService.setDefaultdivValues($scope);
		$scope.nodelevel=scope.$nodeScope.$modelValue.nodelevel;
		var request = $scope.constructRequestObj($scope);
		var success = false;
		var parentid ='';
		if(scope.$nodeScope.$parentNodeScope != null)
			{parentid= scope.$nodeScope.$parentNodeScope.$modelValue.id;}
		else
			{ parentid=null; }
		
		var currentNodelevel = scope.$nodeScope.$modelValue.nodelevel;

		if($sessionStorage.role == AppConstants.RoleEnum['admin'])
		{
			request.username='';
			request.id='';
			ViewReportService.deleteglobalTemplate(request).success(function(data, status){

			});
		}
		else{
			ViewReportService.deleteReportTemplate(request).success(function(data, status) {
				console.log(" data   "+data);
				if(status == 200)
				{
					ManageDivService.enableShowReportView($scope,false);

					var index = scope.$nodeScope.$parentNodesScope.$modelValue.indexOf(scope.$nodeScope.$modelValue);
					if (index > -1) {

						scope.$nodeScope.$parentNodesScope.$modelValue.splice(index, 1)[0];
					}
					$scope.SelectedNode={
							$nodeScope:scope.$nodeScope.$parentNodeScope
					};
					$scope.CurrentNode=scope.$nodeScope.$parentNodeScope;
					scope.$nodeScope.$parentNodesScope.collapse=false;
					scope.$nodeScope.$parentNodesScope.collapse=false;
					scope.$nodeScope.collapse=false;

					$scope.records = '';
					$scope.tableColumns = '';
					$scope.newReport.tabcolumns='';	

					$window.alert('Report is Deleted Successfully.');}
				else
					{
					$window.alert('Unfortunatly , Report is not deleted due to some error.');
					}
			});
		}
		$scope.showResultMessage=true;
		$scope.resultMessage='Node Succesfully deleted';
		
		
		}
		
	};

	$scope.toggle = function (scope) {
		scope.toggle();
	};

	$scope.moveLastToTheBeginning = function () {
		var a = $scope.data.pop();
		$scope.data.splice(0, 0, a);
	};

	$scope.insertReportTemplate= function (scope) {
	var tempNode=scope;
	var nodeData = scope.$modelValue;
	if(nodeData=='' || nodeData==null)
	{
		nodeData = scope.$nodeScope.$modelValue;
	}
	if(nodeData.nodelevel==null)
	{
		nodeData.nodelevel=nodeData.node.nodelevel;
	}
	scope.$nodeScope.collapsed=false;
	tempNode={
			$nodeScope:{
				collapsed:false,
				$parentNodeScope:scope,
				$parentNodesScope:scope.$nodeScope.$parentNodesScope,
				$parentNodesScope:{$modelValue:scope.$nodeScope.$modelValue.nodes},
				$modelValue:{
					id: ViewReportService.genrateUniqueId(),
					label: nodeData.label + '.' + (nodeData.nodes.length + 1),
					nodelevel:nodeData.nodelevel+ '.' + (nodeData.nodes.length + 1),
					nodes: []}
			}
	};


	$scope.reportParentId=tempNode.$nodeScope.$parentNodeScope.$nodeScope.$modelValue.id;
	$scope.reportId=tempNode.$nodeScope.$modelValue.id;

	$scope.nodelevel = tempNode.$nodeScope.$modelValue.nodelevel;

	$scope.request.username=$scope.username;
	$scope.request.id=$scope.templtid;
	$scope.newReportName=tempNode.$nodeScope.$modelValue.label;


	var request = $scope.constructRequestObj($scope);


	//if role is admin then report will be added as gobal template in db
	if($sessionStorage.role == AppConstants.RoleEnum['admin'])
	{
		request.username='';
		request.id='';
		ViewReportService.insertGlobalTemplate(request).success(function(data, status) {
			if(status == 200){
				console.log("New Report Template is inserted successfully");

				nodeData.nodes.push(tempNode.$nodeScope.$modelValue);
				$scope.SelectedNode=tempNode;
				$scope.CurrentNode=tempNode;
				$scope.request.node='';
				$scope.getNewReportScreen(data);
			}
		});
	}

	else{
		ViewReportService.insertNewReportTemplate(request).success(function(data, status) {
			if(status == 200){
				console.log("New Report Template is inserted successfully");

				nodeData.nodes.push(tempNode.$nodeScope.$modelValue);
				$scope.SelectedNode=tempNode;
				$scope.CurrentNode=tempNode;
				$scope.request.node='';
				$scope.getNewReportScreen(data);}
		});
	}

};

	$scope.collapseAll = function () {
		$scope.$broadcast('angular-ui-tree:collapse-all');
	};

	$scope.expandAll = function () {
		$scope.$broadcast('angular-ui-tree:expand-all');
	};

	
	
	
	
	
	
	$scope.emailReport = function(){
		
		

		
		switch($scope.attachmentType){
		case 'XLS':
		{
			$scope.attachmentType="XLS";
		};
		break;
		case 'CSV':
		{
			$scope.attachmentType="CSV";
		};
		break;
		case 'PDF':
		{
			$scope.attachmentType="PDF";
		};
		break;
		default:
			break;
		}


		$scope.request=$scope.constructRequestObj($scope);
				

	
					
			$scope.loading=true;
		    ViewReportService.emailReport($scope,$scope.request).success(function(data, status) {
			ManageDivService.setDefaultdivValues($scope);
			ManageDivService.enableShowReportView(true,$scope);
			
			$scope.loading=false;
		});
		
		
		
		
		

	};
	
     $scope.selectAllValuesForColumns=function()
     {
    	 $scope.newReport.tabcolumns=$scope.tableColumns1;
     }
     
     $scope.deselectValuesForColumns=function()
     {
    	 $scope.newReport.tabcolumns=[];
     }
}]);

