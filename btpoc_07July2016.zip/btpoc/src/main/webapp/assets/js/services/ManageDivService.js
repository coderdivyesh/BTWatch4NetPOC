
(function () {
	'use strict';
angular.module('reportTool').factory('ManageDivService', [ function (){
	
	return {
		
		setDefaultdivValues : function(object)
		 {
			object.showReportTable=false;
			object.disableNext =true;
			object.disablePrevious = true;
			object.displayNewReportTab=false;
			object.displayGraph=false;
			object.enableDisplayOptions = false;
			object.showResultMessage = false;
			object.callShowReport=true;
		 },
		 
		 setDefaultdivValuesForAdminView : function(object)
		 {
			 object.showSuccessMessage=false;
			 object.showUserListdiv= false;
			 object.showUserScreendiv= false;
			 object.showUpdSuccessMessage=false;
			 object.showActiveUserListdiv= false;
			 object.killActiveUser = false;
			 object.showUserRegistreationForm=false;
		 },
		 
		 enableShowReportView :function (value,object)
		 {
			 object.showReportTable = value;
			 object.disableNext=false;
		 },
		 
		enabledisplayOptionView : function (value,object)
		 {
			object.enableDisplayOptions=value;
			
		 },
		 
		enableNewReportView : function (value,object)
		 {
			object.displayNewReportTab=value;
				
		 },
		 
		 enableResultDisplayMessage : function(value,object)
		 {
			 object.showResultMessage = value;
		 },
		 
		
		 enableGraphView : function(value,object)
		 {
			 object.displayGraph=value;
		 },
		 
		 enableReportAddOptions:function(value,object)
		 {
			 object.enableReportAddOption=value;
		 },
		 
		 enableSuccessMsgViewForAdmin : function(value,object)
		 {
			 object.showSuccessMessage=value;
		 },
	
		 enabledisplayUserViewForAdmin :  function(value,object)
		 {
			 object.showUserListdiv= value;
		 },
		 enableUserRegistrationView :function (value,object)
		 {
			 object.showUserRegistreationForm=value;
		 },
		 displayActiveUserView :  function(value,object)
		 {
			 object.showActiveUserListdiv= value;
		 },
		 enableExistingUserUpdateView : function(value,object)
		 {
			 object.showUserScreendiv= value;
		 }
	}
}]);
}());